description=/home/rice/phasespace-generator/description_of_beam/description-proton.sh

nominalEnergies=$(<energy_p)
#nominalEnergies="48.1 121.1 98.0"

foci="1 2 3"

for focus in $foci; do
     for nominalEnergy in $nominalEnergies ; do
        Parameter $nominalEnergy $focus > temp.txt
        nominalEnergyRound=$(cat temp.txt | tail -n 1 | cut -d':' -f1)
        realEnergy=$(cat temp.txt | tail -n 1 | cut -d':' -f2)
        Energywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f3)
        xwidth=$(cat temp.txt | tail -n 1 | cut -d':' -f4)
        ywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f5)
        cxwidth=$(cat temp.txt | tail -n 1 | cut -d':' -f6)
        cywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f7)
        
        echo nominalEnergyRound $nominalEnergyRound realEnergy $realEnergy Energywidth $Energywidth xwidth $xwidth ywidth $ywidth cxwidth $cxwidth cywidth $cywidth focus $focus
        
        $description -e $realEnergy -n $nominalEnergyRound -f $Energywidth -x $xwidth -y $ywidth -c $cxwidth -d $cywidth -j $focus
     
     done
done

inputFile=input1

if [ -e $inputFile ] ; then
   \rm $inputFile
fi
