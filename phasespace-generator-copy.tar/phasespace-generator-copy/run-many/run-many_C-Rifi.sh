description=/home/rice/phasespace-generator/description_of_beam/description-C.sh

nominalEnergies=$(<energy_C)
#nominalEnergies="110.6"
foci="2 3 4 5"

for focus in $foci; do
for nominalEnergy in $nominalEnergies ; do
   Parameter-carbon $nominalEnergy $focus  > temp_C-Rifi.txt
   nominalEnergyRound=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f1)
   realEnergy=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f2)
   Energywidth=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f3)
   xwidth=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f4)
   ywidth=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f5)
   cxwidth=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f6)
   cywidth=$(cat temp_C-Rifi.txt | tail -n 1 | cut -d':' -f7)
   
   echo nominalEnergyRound $nominalEnergyRound realEnergy $realEnergy
   echo Energywidth $Energywidth xwidth $xwidth ywidth $ywidth 

  Scalex=1
  Scaley=1
echo $description -e $realEnergy -n $nominalEnergyRound -f $Energywidth -x $xwidth -y $ywidth -c $cxwidth -d $cywidth -j $focus
$description -e $realEnergy -n $nominalEnergyRound -f $Energywidth -x $xwidth -y $ywidth -c $cxwidth -d $cywidth -j $focus
done
done
inputFile=input

if [ -e $inputFile ] ; then
   \rm $inputFile
fi
   
