#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cmath>
#include <iostream>
#include <complex>
#include <cstdlib>
#include <fstream>
#include "TRandom.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TFile.h"
#include "TMath.h"
#include "TGraph.h"

using namespace std;

//==================================================================================================
int main(int argc, char *argv[]){

  float nominalEnergy=86.2;
  if ( argc > 1 ) nominalEnergy=atof(argv[1]);

  int focus=1;
  if ( argc > 2 ) focus=atoi(argv[2]);

  char parameterFile[300];
	 
  int a=(nominalEnergy+0.055)*100.0;
  int  d=a/10.0;
  nominalEnergy=d/10.0;

  int nFoci=5;
  int nEnergy=16 ; 

 int nCol=8;

   ifstream file, file1;

//   sprintf(parameterFile,"/home/rice/phasespace-generator/TuningParameters/temp-good/proton/parameter.dat");
   sprintf(parameterFile,"/home/rice/phasespace-generator/TuningParameters/carbon/parameter-carbon.dat");
                         
   file.open(parameterFile,ios::in);
   float Data[nCol+1];
   int n=0;
   string line;

   if(!file.is_open())
    {
        cout<<"It failed"<<endl;
        return 0;
    }

    while(getline(file,line))
      n++;

    file.close();

  double x[n+1], y[n+1], yew[n+1], xw[n+1], yw[n+1], cxw[n+1], cyw[n+1];
 
  int k=0;

  file1.open(parameterFile,ios::in);
 
    for (int j=1; j<=n; j++)
    {
         for (int i=1; i<=nCol; i++){
         file1>>Data[i];    
         }
         int Fo=Data[1];
             if(Fo == focus)
             {
              k=k+1;
              x[k] =Data[2];
              y[k] =Data[3]/12.0-Data[2];
              yew[k] = Data[4];
              xw[k] = Data[5];
              yw[k] = Data[6];
              cxw[k] = Data[7];
              cyw[k] = Data[8];                                                      
             }
    }
  
//For ennergy shift
  TGraph *g = new TGraph(k, x, y);
  g->SetName("Energy shift");
  TGraph *gew = new TGraph(k, x, yew);
  gew->SetName("Energy distribution");

   float realEnergy =12*(g->Eval(nominalEnergy)+nominalEnergy); 
   float Energywidth = gew->Eval(nominalEnergy);


//X-width
  TGraph *gx = new TGraph(k, x, xw);
  gx->SetName("X-width");
  TGraph *gy = new TGraph(k, x, yw);
  gy->SetName("Y-width");
  TGraph *gcx = new TGraph(k, x, cxw);
  gcx->SetName("cosx-width");
  TGraph *gcy = new TGraph(k, x, cyw);
  gcy->SetName("cosy-width");

   float xwidth = gx->Eval(nominalEnergy);  
   float ywidth = gy->Eval(nominalEnergy);
   float cxwidth = gcx->Eval(nominalEnergy);   
   float cywidth = gcy->Eval(nominalEnergy);
   
//  cout<<"-n "<<nominalEnergy<<" -e "<<realEnergy<<" -f "<<Energywidth<<" -x "<<xwidth<<" -y "<<ywidth<<" -c "<<cxwidth<<" -d "<<cywidth<<endl;
   if (nominalEnergy<100.0){	 
   printf("%4.1f:%f:%f:%f:%f:%f:%f\n",nominalEnergy,realEnergy,Energywidth, xwidth, ywidth, cxwidth, cywidth );}
   else {
   printf("%5.1f:%f:%f:%f:%f:%f:%f\n",nominalEnergy,realEnergy,Energywidth, xwidth, ywidth, cxwidth, cywidth );}

   exit(1);

}
