#!/bin/bash

enegy=100
nEnergy=100
de=1.65
dx=1
dy=1
dcx=0.05
dcy=0.05
foci=3

while getopts e:f:x:y:j:c:d:hn: flag
do
  case $flag in
    c) dcx=$OPTARG ;;
    d) dcy=$OPTARG ;;
    e) energy=$OPTARG ;;
    f) de=$OPTARG ;;
    n) nEnergy=$OPTARG ;;
    x) dx=$OPTARG ;;
    y) dy=$OPTARG ;;
    j) foci=$OPTARG ;;	
    h) echo "HELP " 
       echo "impt-gui-beam.sh -h (--help     ): print this help "
       echo "                 -a (--beamlets ): Save Information for all beamlets "
       echo "                 -b (--beam     ): Beam Number "
       echo "                 -c (--cohort   ): Cohort for db "
       exit
     ;;
      ?) exit ;;
  esac
done

shift $(( OPTIND - 1 ))  # shift past the last flag or argument

echo energy $energy
echo de     $de
echo dx     $dx
echo dy     $dy
echo dcx    $dcx
echo dcy    $dcy

inputFile=input
if [ -e $inputFile ] ; then
   \rm $inputFile
fi

cat >> $inputFile << EOF
$energy $de
0.0 $dx
0.0 $dy
0.0 $dcx
0.0 $dcy
EOF


iEnergy=$(echo $nEnergy | cut -d'.' -f1)
if [ $iEnergy -le 99 ]; then
outputFile=/data/rice/phasespace/proton/proton-foci-$foci/Shanghai-0$nEnergy.bin
else
outputFile=/data/rice/phasespace/proton/proton-foci-$foci/Shanghai-$nEnergy.bin
fi

if [ -e $outputFile ] ; then
   \rm $outputFile
fi

/home/sphic/phasespace-generator/description_of_beam/description.x $outputFile
ls $outputFile

