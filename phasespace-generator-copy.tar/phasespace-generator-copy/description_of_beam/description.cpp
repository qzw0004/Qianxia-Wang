#include <stdio.h> 
#include <string.h>  
#include <math.h>  
#include <cmath>
#include <iostream>
#include <complex>
#include <cstdlib>
#include <fstream>
#include "TRandom.h"
#include "TH1F.h"
#include "TFile.h"

using namespace std;
//           Qianxia Wang  11-15-2016
const int nE=1000, nX=1000, nY=1000, nTHETA=50, nPHI=50;  // number of experiments
const int n=2000,nparticles=1000000;
      int binnum,binnum1,binnumE1,binnumE2,binnumt1,bin[n+2],binnumt2;
   double binE, binX, binY,binZ, binTHETA, binPHI, Vt, Vx, Vy, Vz,kk;

int m,h;
complex<double> one,zero,iii; 
       double  E_c, X_c, Y_c, Vx_c, Vy_c, FWHME, FWHMX, FWHMY, FWHMVx, FWHMVy, a[n+2],
	   thegamaE, b, binstep, Data[20][20];
char binFileName[400];
int   NumRows;          // Number of rows in array
int   NumColumns;       // Number of columns in array

//===========================================================================================
//
class FdcVector {
public:
   float gx ; 
   float gy ; 
   float gz ; 
   void set ( float xx, float yy, float zz ) { gx = xx ; gy = yy ; gz = zz ; }
};

//

class FdcParticleStack {
public:
      int          species ;
      float        energy ;
      float        weight ;
      FdcVector    direction;
      FdcVector    position ;

 void set ( int species_, float energy_, const double* pnt, const double* dir ) {
    species = species_ ;
    energy  = energy_ ;
    direction.set ( dir[0], dir[1], dir[2] ) ;
    position.set ( pnt[0], pnt[1], pnt[2] ) ;
 } 
};
//===========================================================================================

FdcParticleStack* par;

int main(int argc, char *argv[])
{
   strcpy(binFileName, "Shanghai_test.bin");
   if(argc > 1 ) strcpy(binFileName, argv[1]);

   printf ("bin  Db file %s \n", binFileName );
	
TRandom random ;
	
//FILE *output1 ; 
//enenrgy distribution
ifstream file;
file.open("input",ios::in); 
int i,j;
    for (i=1; i<=5; i++) 
    {
        for (j=1; j<=2; j++) 
        {
         file>>Data[i][j];
        }
    }

E_c=Data[1][1];
X_c=Data[2][1];
Y_c=Data[3][1];
Vx_c=Data[4][1];
Vy_c=Data[5][1];
FWHME=Data[1][2];
FWHMX=Data[2][2];
FWHMY=Data[3][2];
FWHMVx=Data[4][2];
FWHMVy=Data[5][2];
binstep=2*E_c/(n*1.0);
double thegamaE=FWHME/(2*sqrt(2*log(2)));
double thegamaX=FWHMX/(2*sqrt(2*log(2)));
double thegamaY=FWHMY/(2*sqrt(2*log(2)));
double thegamaVx=FWHMVx/(2*sqrt(2*log(2)));
double thegamaVy=FWHMVy/(2*sqrt(2*log(2)));

printf ("nParticles %d \n", nparticles);
FILE* binFile = fopen(binFileName,"wb");
fwrite(&nparticles, sizeof(int), 1, binFile);

TFile fout("phase-space-plots.root", "RECREATE");

TH1F* hEnergy = new TH1F("Energy","Energy", 100, E_c-5*thegamaE, E_c+5*thegamaE);
TH1F* hx      = new TH1F("x","x pos", 100, X_c-5*thegamaX, X_c+5*thegamaX);
TH1F* hy      = new TH1F("y","y pos", 100, Y_c-5*thegamaY, Y_c+5*thegamaY);
TH1F* hVx     = new TH1F("vx","vx", 100, -5*thegamaVx, 5*thegamaVx);
TH1F* hVy     = new TH1F("vy","vy", 100, -5*thegamaVy, 5*thegamaVy);
TH1F* hVz     = new TH1F("vz","vz", 100, -1., -0.05);


FdcParticleStack par;

for (int m1=1; m1<=nparticles; ++m1){

binE=random.Gaus(E_c,thegamaE);
binX=random.Gaus(X_c,thegamaX);
binY=random.Gaus(Y_c,thegamaY);
Vx=random.Gaus(0,thegamaVx);
Vy=random.Gaus(0,thegamaVy);
Vz=-1.*sqrt(1-Vx*Vx-Vy*Vy);

hEnergy->Fill(binE);
hx->Fill(binX);
hy->Fill(binY);
hVx->Fill(Vx);
hVy->Fill(Vy);
hVz->Fill(Vz);

par.weight = 1.0;
par.species= 15;   // proton
//par.species= 6012; //Carbon
par.energy = binE;
par.direction.gx = Vx;
par.direction.gy = Vy;
par.direction.gz = Vz;
par.position.gx = binX;
par.position.gy = binY;
par.position.gz = binZ;

fwrite(&par, sizeof(FdcParticleStack), 1, binFile);

}
fclose(binFile);
fout.Write();
fout.Close();

}
