nominalEnergies=(048.1 085.7 104.5 124.2 141.9 163.3 182.9 199.0 221.1)
#nominalEnergies=(104.5)
nHistories=100M

echo ${nominalEnergies[@]}
for nominalEnergy in "${nominalEnergies[@]}" ; do
   phantom-all_P.sh -n $nHistories -q $nominalEnergy   
done
