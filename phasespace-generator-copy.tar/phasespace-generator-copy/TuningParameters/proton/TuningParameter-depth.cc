#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cmath>
#include <iostream>
#include <complex>
#include <cstdlib>
#include <fstream>
#include "TRandom.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TFile.h"
#include "TMath.h"
#include "TGraph.h"

using namespace std;

//==================================================================================================
int main(int argc, char *argv[]) {
	
//**************************************************************************************************
// Measurement
//**************************************************************************************************	

//measurement reading
     float nominalEnergy=104.5;
     if ( argc > 1 ) nominalEnergy=atof(argv[1]);

     int focus=1;
     if ( argc > 2 ) focus=atoi(argv[2]);
    
     int eng=1;
     if ( argc > 3 ) eng=atoi(argv[3]);
	 
	 char energyName[300];
	 
	 if (nominalEnergy<100.0) sprintf (energyName, "0%4.1f", nominalEnergy);
	 else sprintf (energyName, "%5.1f", nominalEnergy);
	 
	 printf("a%sa\n", energyName);

	 
//    TFile fhis1("/data/qwang11/SPHIC-Spot-data/3mmRifi.root"); 
//    TFile fhis1("/data/rice/DDD-data/Proton-scale.root");
    TFile fhis1("/data/qw14/SPHIC-Spot-data/proton-DDD.root");
  
   TGraph* meas = (TGraph*)fhis1.Get(energyName);//????????????????????????????????????????

     if ( meas == NULL ) {
       printf("meas not found \n" );
       return 0 ;
     }

     int num=meas->GetN();
     double ax1[num+1], ay1[num+1];
     int looplimit=51;
	
     for(int i=0; i<num; i++) 
	 {
        meas->GetPoint(i, ax1[i], ay1[i]); 
     }
	
//end of measurement reading

//normalization and finding peak for measurement

     for (int i=0;i<num;i++)
	 {
        ax1[i]=ax1[i]-1.685;
        meas->SetPoint(i, ax1[i], ay1[i]);
     }
	
    double xmin=ax1[0];
    double xmax=ax1[num-1];
     
     printf("xmin %f xmax %f\n",xmin,xmax);
	 
     double integral=0.0;
     
     for(int i=0; i<num-1; i++)
	 {
        if ( ax1[i] >= xmin && ax1[i] <= xmax ) {
	    integral=integral+(ay1[i+1]+ay1[i])/2.0*(ax1[i+1]-ax1[i]);
        }
     }
	
	 float scale=1.0/integral;

     for(int i=0; i<num; i++){
	     ay1[i]*= scale;
	     meas->SetPoint(i, ax1[i], ay1[i]);
     }
	 
	 double PeakMea=0.0;
	 double PeakMeaPos;
	 int ihalf;
	 for(int i=0; i<num; i++){
	     if(ay1[i]>PeakMea)
	     {
	     PeakMea = ay1[i];
	     PeakMeaPos=ax1[i];
         ihalf=i;
	     }
	 }
// end of normalization and finding peak for measurement

     double deltaY=10000000;
	 double halfHL, halfHPositionL;
	 for(int i=0; i<ihalf; i++){
		 double deltaYY=abs(ay1[i]-0.5*PeakMea);
	     if(deltaYY<deltaY)
	     {
		 deltaY=deltaYY; 
	     halfHL = ay1[i];
	     halfHPositionL=ax1[i];
	     }
	 }
	 
	 deltaY=10000000;
	 double halfHR, halfHPositionR;
	 
	 for(int i=ihalf; i<num; i++){
		 double deltaYY=abs(ay1[i]-0.5*PeakMea);
	     if(deltaYY<deltaY)
	     {
		 deltaY=deltaYY; 
	     halfHR = ay1[i];
	     halfHPositionR=ax1[i];
	     }
	 }

	double fwhmMea = halfHPositionR-halfHPositionL;
	
//**************************************************************************************************
// End of Measurement
//**************************************************************************************************

    float realEnergy  = nominalEnergy;
	float EnergyWidth = 2;
	
	string str1="/home/rice/phasespace-generator/description_of_beam/description.sh";
	string str2="/home/rice/phasespace-generator/TuningParameters/proton/phantom-all_P.sh";
	
	char variable1[300];
	char variable2[300];
	char variableLx[300];
	char variableLy[300];
	char CalName[300];
	char CalNamex[300];
	char CalNamey[300];
    float deltaEnergy;
	float deltaFWHMe;
	float ratio=0.1;
	float ratioE=1;
	float ratioEo=ratioE;
	float ratioo=ratio;
	float NewFWHMe;
	int nnn=0;
	int nnE=0;
	int nnEw=0;
	
	float  fwhmCalO    ; 
	float  fwhmMeaO    ;
	float  PeakCalPosO ;
	float  PeakMeaPosO ;
	int IIIIIIIIII=0;
	int sign;
	
	for (; ;)
	{
     IIIIIIIIII++;
	 
	 cout<<IIIIIIIIII<<endl;
	 
    if (nominalEnergy<100) 	sprintf(variable1, " -n %4.1f -e %f -f %f\n", nominalEnergy, realEnergy, EnergyWidth);
    else 	sprintf(variable1, " -n %5.1f -e %f -f %f\n", nominalEnergy, realEnergy, EnergyWidth);

	string Ph= str1 + variable1;
	const char *command1 = Ph.c_str();
	printf("%s\n", command1);
    system(command1);
	
	if (nominalEnergy<100) sprintf(variable2, " -n 100M -g %i -q %4.1f\n", eng, nominalEnergy);
    else 	sprintf(variable2, " -n 100M -g %i -q %5.1f\n", eng, nominalEnergy);
	
    if (nominalEnergy<100) sprintf(variableLx, " -n 100M -g %i -q %4.1f -p x\n", eng, nominalEnergy);
    else 	sprintf(variableLx, " -n 100M -g %i -q %5.1f -p x\n", eng, nominalEnergy);
	
	if (nominalEnergy<100) sprintf(variableLy, " -n 100M -g %i -q %4.1f -p y\n", eng, nominalEnergy);
    else 	sprintf(variableLy, " -n 100M -g %i -q %5.1f -p y\n", eng, nominalEnergy);
		
	string FDC= str2 + variable2;
	const char *command2 = FDC.c_str();
	printf("%s\n", command2);
    system(command2);
   
    if (nominalEnergy<100.0) sprintf(CalName,"/data/rice/guidata/shanghai-100M-%4.1f.root",nominalEnergy);
    else                     sprintf(CalName,"/data/rice/guidata/shanghai-100M-%5.1f.root",nominalEnergy);

// Calculation projected in z

   TFile fin(CalName);
   
//   printf("%s\n", CalName);
	
   TH3F* edep = (TH3F *)fin.Get("voxelEnergy");

   if ( edep == NULL ) {
      printf("edep not found \n" );
      return(1) ;
   }

    printf("edep %p\n", edep );

	int ixMin = edep->GetXaxis()->FindBin(-40);
    int ixMax = edep->GetXaxis()->FindBin(40);
	
	printf("ixMin %d ixMax %d\n", ixMin, ixMax);
	
    edep->GetXaxis()->SetRange(ixMin,ixMax);
	
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
	
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
	
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep = (TH1F *)(edep->Project3D("z"));

    h1Edep->GetXaxis()->SetLimits(0, 500.0);
	
// end of calculation projected in z

//*************************************************************************************************************
//
//*************************************************************************************************************

//normalization and finding peak for calculation

    int bmin= h1Edep->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep->GetXaxis()->FindBin(xmax);

    double integral=h1Edep->Integral(bmin,bmax)*h1Edep->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep->Scale(scale);
	
//end of normalization and finding peak for calculation	

//*************************************************************************************************************
//
//*************************************************************************************************************

	double PeakCal=h1Edep->GetBinContent(h1Edep->GetMaximumBin());
	double PeakCalPos=h1Edep->GetXaxis()->GetBinCenter(h1Edep->GetMaximumBin());

//check FWHM

     float y = 0.5*PeakCal;
	 
     int bin1 = h1Edep->FindFirstBinAbove(y);
     int bin2 = h1Edep->FindLastBinAbove(y);
	 
     double fwhmCal = h1Edep->GetBinCenter(bin2)-h1Edep->GetBinCenter(bin1);
	
     cout<<"1111111111111111111111111111111111111111111111 "<<PeakCalPos<<", "<<PeakMeaPos<<endl;
     cout<<"1111111111111111111111111111111111111111111111 "<<abs(PeakCalPos-PeakMeaPos)<<endl;
   
     if (abs(PeakCalPos-PeakMeaPos)>0.05)
	 {
	   nnE=nnE+1;
	     if (nnE>1){
		      if ((PeakCalPosO-PeakMeaPosO)*(PeakCalPos-PeakMeaPos)>0.0) ratio=1.25*ratio;
			  else       ratio=1/1.25*ratio;
         } 
		  else ratio=ratioo;
		  
	    for (; ;){
	         deltaEnergy = ratio*(PeakMeaPos-PeakCalPos);
	         if ((realEnergy+deltaEnergy)<=0.0) ratio=0.5*ratio;
		     else break;
	     }
		 
	 }
      else 
	  {
	  nnE=0;
	  deltaEnergy=0.0;
	  }
	  
      realEnergy=realEnergy+deltaEnergy;
	  
	 if(abs(fwhmCal-fwhmMea)/fwhmMea>0.15){
		 nnEw=0;
		 if ((fwhmCal-fwhmMea)>0.0) sign=-1;
		 else                      sign=1;
         deltaFWHMe=sign*0.5*EnergyWidth;
	 }
	 else
	 {
		 if(abs(fwhmCal-fwhmMea)/fwhmMea>0.005){
		     nnEw=nnEw+1;
		     if(nnEw>1)
		     {
                 if((fwhmCalO-fwhmMeaO)*(fwhmCal-fwhmMea)>0.0) ratioE=1.25*ratioE;
                 else          ratioE=1/1.25*ratioE;  			 
	          }
		      
		     else ratioE=ratioEo;
		  
		     deltaFWHMe = ratioE*(fwhmMea-fwhmCal)/fwhmMea;
	     }
	     else
	     {
	  	   nnEw=0;
	  	   deltaFWHMe= 0.0;
	     }
	 }  
            EnergyWidth = EnergyWidth + deltaFWHMe;
		     if (EnergyWidth<0.03){  
		  	    deltaFWHMe=0.0;
		        EnergyWidth= 0.03;}
	  	   fwhmCalO    = fwhmCal;
	  	   fwhmMeaO    = fwhmMea;
	  	   PeakCalPosO = PeakCalPos;
	  	   PeakMeaPosO = PeakMeaPos;
		   
		 cout<<"2222222222222222222222222222222222222 "<<fwhmCal<<", "<<fwhmMea<<endl;
         cout<<"222222222222222222222222222222222222222 "<<abs(fwhmCal-fwhmMea)<<endl;  
	  	   
         if (abs(PeakCalPos-PeakMeaPos)<0.2 && abs(fwhmCal-fwhmMea)/fwhmMea<0.01){
	         cout<<"satisfy the standard"<<endl;
      	  break;
         }  
	     if (abs(deltaEnergy)<0.01 && abs(deltaFWHMe) < 0.01) nnn=nnn+1;
             else nnn=0;
	     cout<<"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"<<nnn<<endl;
	     if (nnn>2) break;
   }
   
   cout<<realEnergy<<", "<<EnergyWidth<<endl;
   	 
   if (nominalEnergy<100.0){
   printf("%4.1f:%f:%f\n",nominalEnergy,realEnergy,EnergyWidth);}
   else {
   printf("%5.1f:%f:%f\n",nominalEnergy,realEnergy,EnergyWidth);}

   return 0;

}
