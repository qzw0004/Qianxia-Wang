Tuning=/home/rice/phasespace-generator/TuningParameters/proton/TuningParameter
#nominalEnergies="48.1 53.04  64.01 73.64 98.02 104.5 118.54 136.74 150.14 164.29 182.9 194.52 201.27 208.3 214.76 221.1"
#nominalEnergies="48.1 59.82 85.67  104.5 121.08 124.2 136.16 141.87 150.14 163.27 175.72 182.9 199.03 205.68 221.1"
#nominalEnergies="48.1 59.82 85.67  104.5 121.08 124.2 136.16 141.87 150.14 163.27 175.72 182.9 199.03 205.68 221.1"
# nominalEnergies=$(<energy_p)

#nominalEnergies="48.1 59.8 85.7 104.5 121.1 124.2 136.2 141.9 150.1 163.3 175.7 182.9 199.0 205.7 221.1" 
#nominalEnergies="53.0 64.0 73.6 98.0 118.5 136.7 164.3 182.9 194.5 201.3 208.3 214.8"
#nominalEnergies="48.1 53.0 64.0 73.6 98.0 104.5 118.5 136.7 150.1 164.3 182.9 194.5 201.3 208.3 214.8 221.1" #foci 1 
#nominalEnergies="85.7 104.5 124.2 136.2"
nominalEnergies="48.1 59.8 85.7 104.5 124.2 136.2 141.9 150.1 163.3 175.7 182.9 199.0 205.7 221.1"

eng=1

foci="3"

inputFile=parameter-proton-eng$eng.out

if [ -e $inputFile ] ; then
   \rm $inputFile
fi


for focus in $foci; do

for nominalEnergy in $nominalEnergies ; do
   $Tuning $nominalEnergy $focus $eng > temp.txt
    nominalEnergyRound=$(cat temp.txt | tail -n 1 | cut -d':' -f1)
    realEnergy=$(cat temp.txt | tail -n 1 | cut -d':' -f2)
    Energywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f3)
    xwidth=$(cat temp.txt | tail -n 1 | cut -d':' -f4)
    ywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f5)
    cxwidth=$(cat temp.txt | tail -n 1 | cut -d':' -f6)
    cywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f7)

cat >> $inputFile << EOF
  $focus $nominalEnergyRound $realEnergy $Energywidth $xwidth $ywidth $cxwidth $cywidth
EOF
cp temp.txt temp-$nominalEnergy-$focus.txt
#rm -rf /data/rice/phasespace/Shanghai-$nominalEnergyRound.bin
#rm -rf /data/rice/guidata/shanghai-100M-$nominalEnergyRound.root
rm -rf /data/rice/guidata/shanghai-lateral-100M-$nominalEnergyRound-x.root
rm -rf /data/rice/guidata/shanghai-lateral-100M-$nominalEnergyRound-y.root
 done
done
