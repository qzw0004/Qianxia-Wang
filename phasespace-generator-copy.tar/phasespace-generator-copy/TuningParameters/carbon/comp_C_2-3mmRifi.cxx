 {
 /////////////////////////////////////////////////////////////////////////////////////////////////////////
    TFile fin_887("/data/rice/guidata/shanghai-C-100M-088.7-Rifi.root");
	
	TFile fhis1_887("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_887 = (TGraph*)fhis1_887.Get("88.8");
	
//    TFile fhis1_887("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
//    TGraph* meas1_887 = (TGraph*)fhis1_887.Get("C_88.7");
	
	TFile fhis2_887("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
    TGraph* meas2_887 = (TGraph*)fhis2_887.Get("C_88.70");
 
    TH3F* edep = (TH3F*)fin_887.Get("voxelEnergy");
 
    int ixMin = edep->GetXaxis()->FindBin(-40);
    int ixMax = edep->GetXaxis()->FindBin(40);
    edep->GetXaxis()->SetRange(ixMin,ixMax);
//  edep->GetXaxis()->SetRange(2,2);

    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_887= (TH1*)(edep->Project3D("z"));

    h1Edep_887->GetXaxis()->SetLimits(0, 500.0);
    h1Edep_887->GetXaxis()->SetRange(1, 4000);
    h1Edep_887->SetStats(0);
	
	int num1_887=meas1_887->GetN();
	
	double ax1_887[num1_887+1], ay1_887[num1_887+1];
	
	for(int i=0; i<num1_887; i++) {
    meas1_887->GetPoint(i, ax1_887[i], ay1_887[i]);
	ax1_887[i]=ax1_887[i]-1.685;
    }
	
	int num2_887=meas2_887->GetN();
	
	double ax2_887[num2_887+1], ay2_887[num2_887+1];
	
	for(int i=0; i<num2_887; i++) {
    meas2_887->GetPoint(i, ax2_887[i], ay2_887[i]); 
	ax2_887[i]=ax2_887[i]-1.685;
    }

	double xmin=ax1_887[0];
	
	double xmax=ax1_887[num1_887-1];
	
	if (xmin<ax2_887[0]){
	xmin=ax2_887[0];
	}	
	
	if (xmax>ax2_887[num2_887-1]){
	xmax=ax2_887[num2_887-1];
	}
	//xmin=19;
    printf("xmin %f xmax %f\n",xmin,xmax);
	
    int bmin= h1Edep_887->GetXaxis()->FindBin(xmin);
    int bmax= h1Edep_887->GetXaxis()->FindBin(xmax);
 
    double integral=h1Edep_887->Integral(bmin,bmax)*h1Edep_887->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral*0.3;
 
    h1Edep_887->Scale(scale);
	
	char hName[300];
    sprintf(hName,"Energy = 88.7 MeV",i);
    h1Edep_887->SetTitle(hName);
   
	double integral=0.0;

    for(int i=0; i<num1_887-1; i++) {
        if ( ax1_887[i] >= xmin && ax1_887[i] <= xmax ) {
	   integral=integral+(ay1_887[i+1]+ay1_887[i])/2.0*(ax1_887[i+1]-ax1_887[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1_887;i++){
	ay1_887[i]*= scale*0.3;
	meas1_887->SetPoint(i, ax1_887[i], ay1_887[i]);
    }
	
	double integral=0.0;
	
    for(int i=0; i<num2_887-1; i++) {
		if ( ax2_887[i] >= xmin && ax2_887[i] <= xmax ) {
	integral=integral+(ay2_887[i+1]+ay2_887[i])/2.0*(ax2_887[i+1]-ax2_887[i]);
		}
    }
	
	scale=1.0/integral;
	
	for (int i=0;i<num2_887;i++){
	ay2_887[i]*= scale*0.25;
	meas2_887->SetPoint(i, ax2_887[i], ay2_887[i]);
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////
    TFile fin1595("/data/rice/guidata/shanghai-C-100M-159.5-Rifi.root");
//    TFile fin1595("/data/sphic/guidata/shanghai-C-1M-v51-159.5-RiFi-3mm.root");
	TH3F* edep = (TH3F *)fin1595.Get("voxelEnergy");
    edep->GetXaxis()->SetRange(2,2);
    iyMin = edep->GetYaxis()->FindBin(-40);
    iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_1595 = (TH1 *)(edep->Project3D("z"));
	
	TFile fhis1595("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_1595 = (TGraph*)fhis1595.Get("159.5");

    h1Edep_1595->GetXaxis()->SetLimits(0,500.0);
    h1Edep_1595->GetXaxis()->SetRange(1,6000);
	h1Edep_1595->SetStats(0);
    
	int num1=meas1_1595->GetN();
	double ax1595[num1+1], ay1595[num1+1];
	
	for(int i=0; i<num1; i++) {
    meas1_1595->GetPoint(i, ax1595[i], ay1595[i]); 
	ax1595[i] =ax1595[i]-1.685;
    }
	

	double xmin=ax1595[0];
	double xmax=ax1595[num1-1];
	
    int bmin= h1Edep_1595->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_1595->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_1595->Integral(bmin,bmax)*h1Edep_1595->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep_1595->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1-1; i++) {
        if ( ax1595[i] >= xmin && ax1595[i] <= xmax ) {
	   integral=integral+(ay1595[i+1]+ay1595[i])/2.0*(ax1595[i+1]-ax1595[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1;i++){
	ay1595[i]*= scale;
	meas1_1595->SetPoint(i, ax1595[i], ay1595[i]);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////
    TFile fin("/data/rice/guidata/shanghai-C-100M-195.7-Rifi.root");
	TH3F* edep = (TH3F *)fin.Get("voxelEnergy");
    edep->GetXaxis()->SetRange(2,2);
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_1957 = (TH1 *)(edep->Project3D("z"));
	
	TFile fhis1("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_1957 = (TGraph*)fhis1.Get("195.7");
	
//    TFile fhis1("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
//    TGraph* meas1_1957 = (TGraph*)fhis1.Get("C_195.7");
	TFile fhis2("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
    TGraph* meas2_1957 = (TGraph*)fhis2.Get("C_195.70");

    h1Edep_1957->GetXaxis()->SetLimits(0,500.0);
    h1Edep_1957->GetXaxis()->SetRange(1,6000);
	h1Edep_1957->SetStats(0);
    
	 num1=meas1_1957->GetN();
	double ax1[num1+1], ay1[num1+1];
	
	for(int i=0; i<num1; i++) {
    meas1_1957->GetPoint(i, ax1[i], ay1[i]); 
  	ax1[i] =ax1[i]-1.685;
    }
	
	int num2=meas2_1957->GetN();
	double ax2[num2+1], ay2[num2+1];
	for(int i=0; i<num2; i++) {
    meas2_1957->GetPoint(i, ax2[i], ay2[i]); 
	ax2[i] =ax2[i]-1.685;
    }

	double xmin=ax1[0];
	double xmax=ax1[num1-1];
	
	if (xmin<ax2[0]){
	xmin=ax2[0];
	}	
	
	if (xmax>ax2[num2-1]){
	xmax=ax2[num2-1];
	}
	
    int bmin= h1Edep_1957->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_1957->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_1957->Integral(bmin,bmax)*h1Edep_1957->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep_1957->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1-1; i++) {
        if ( ax1[i] >= xmin && ax1[i] <= xmax ) {
	   integral=integral+(ay1[i+1]+ay1[i])/2.0*(ax1[i+1]-ax1[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1;i++){
	ay1[i]*= scale;
	meas1_1957->SetPoint(i, ax1[i], ay1[i]);
    }
	
	double integral=0.0;
    for(int i=0; i<num2-1; i++) {
		if ( ax2[i] >= xmin && ax2[i] <= xmax ) {
	integral=integral+(ay2[i+1]+ay2[i])/2.0*(ax2[i+1]-ax2[i]);
		}
    }
	
	scale=1.0/integral;
	
	for (int i=0;i<num2;i++){
	ay2[i]*= scale;
	meas2_1957->SetPoint(i,ax2[i], ay2[i]);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////
    TFile fin2341("/data/rice/guidata/shanghai-C-100M-234.1-Rifi.root");
	TH3F* edep = (TH3F *)fin2341.Get("voxelEnergy");
    edep->GetXaxis()->SetRange(2,2);
    iyMin = edep->GetYaxis()->FindBin(-40);
    iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_2341 = (TH1 *)(edep->Project3D("z"));
	
	TFile fhis2341("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_2341 = (TGraph*)fhis2341.Get("234.1");

    h1Edep_2341->GetXaxis()->SetLimits(0,500.0);
    h1Edep_2341->GetXaxis()->SetRange(1,6000);
	h1Edep_2341->SetStats(0);
    
	int num1=meas1_2341->GetN();
	double ax2341[num1+1], ay2341[num1+1];
	
	for(int i=0; i<num1; i++) {
    meas1_2341->GetPoint(i, ax2341[i], ay2341[i]); 
	ax2341[i] =ax2341[i]-1.685;
    }
	

	double xmin=ax2341[0];
	double xmax=ax2341[num1-1];
	
    int bmin= h1Edep_2341->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_2341->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_2341->Integral(bmin,bmax)*h1Edep_2341->GetXaxis()->GetBinWidth(1);
    scale=1.0/integral;

	h1Edep_2341->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1-1; i++) {
        if ( ax2341[i] >= xmin && ax2341[i] <= xmax ) {
	   integral=integral+(ay2341[i+1]+ay2341[i])/2.0*(ax2341[i+1]-ax2341[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1;i++){
	ay2341[i]*= scale;
	meas1_2341->SetPoint(i, ax2341[i], ay2341[i]);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////

    TFile fin_2689("/data/rice/guidata/shanghai-C-100M-268.9-Rifi.root");

    TH3F* edep = (TH3F *)fin_2689.Get("voxelEnergy");

    edep->GetXaxis()->SetRange(2,2);
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);

    edep->GetXaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_2689 = (TH1 *)(edep->Project3D("z"));
    h1Edep_2689->GetXaxis()->SetLimits(0,500.0);
    h1Edep_2689->GetXaxis()->SetRange(1,6000);
    h1Edep_2689->SetStats(0);
	
	TFile fhis1_2689("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_2689 = (TGraph *)fhis1_2689.Get("268.9");
	
//    TFile fhis1_2689("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
//    TGraph* meas1_2689 = (TGraph *)fhis1_2689.Get("C_268.90");
	
	TFile fhis2_2689 ("/home/qw14/02_AnnualQA_1/20160211_TR1_annualQA/TR1_0211.root");
    TGraph* meas2_2689 = (TGraph *)fhis2_2689.Get("C_268.9");
	
	int num1_2689=meas1_2689->GetN();
	double ax1_2689[num1_2689+1], ay1_2689[num1_2689+1];
	
	for(int i=0; i<num1_2689; i++) {
    meas1_2689->GetPoint(i, ax1_2689[i], ay1_2689[i]); 
	ax1_2689[i] =ax1_2689[i]-1.685;
    }
	
	int num2_2689=meas2_2689->GetN();
	double ax2_2689[num2_2689+1], ay2_2689[num2_2689+1];
	
	for(int i=0; i<num2_2689; i++) {
    meas2_2689->GetPoint(i, ax2_2689[i], ay2_2689[i]); 
	ax2_2689[i] =ax2_2689[i]-1.685;
    }

	double xmin=ax1_2689[0];
	double xmax=ax1_2689[num1_2689-1];
	
	if (xmin<ax2_2689[0]){
	xmin=ax2_2689[0];
	}	
	
	if (xmax>ax2_2689[num2_2689-1]){
	xmax=ax2_2689[num2_2689-1];
	}
	
    int bmin= h1Edep_2689->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_2689->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_2689->Integral(bmin,bmax)*h1Edep_2689->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep_2689->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1_2689-1; i++) {
        if ( ax1_2689[i] >= xmin && ax1_2689[i] <= xmax ) {
	   integral=integral+(ay1_2689[i+1]+ay1_2689[i])/2.0*(ax1_2689[i+1]-ax1_2689[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1_2689;i++){
	ay1_2689[i]*= scale;
	meas1_2689->SetPoint(i, ax1_2689[i], ay1_2689[i]);
    }
	
	double integral=0.0;
    for(int i=0; i<num2_2689-1; i++) {
		if ( ax2_2689[i] >= xmin && ax2_2689[i] <= xmax ) {
	integral=integral+(ay2_2689[i+1]+ay2_2689[i])/2.0*(ax2_2689[i+1]-ax2_2689[i]);
		}
    }
	
	scale=1.0/integral;
	
	for (int i=0;i<num2_2689;i++){
	ay2_2689[i]*= scale;
	meas2_2689->SetPoint(i,ax2_2689[i], ay2_2689[i]);
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////
    TFile fin3116("/data/rice/guidata/shanghai-C-100M-311.6-Rifi.root");
	TH3F* edep = (TH3F *)fin3116.Get("voxelEnergy");
    edep->GetXaxis()->SetRange(2,2);
    iyMin = edep->GetYaxis()->FindBin(-40);
    iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_3116 = (TH1 *)(edep->Project3D("z"));
	
	TFile fhis3116("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_3116 = (TGraph*)fhis3116.Get("311.6");

    h1Edep_3116->GetXaxis()->SetLimits(0,500.0);
    h1Edep_3116->GetXaxis()->SetRange(1,6000);
	h1Edep_3116->SetStats(0);
    
	int num1=meas1_3116->GetN();
	double ax3116[num1+1], ay3116[num1+1];
	
	for(int i=0; i<num1; i++) {
    meas1_3116->GetPoint(i, ax3116[i], ay3116[i]); 
	ax3116[i] =ax3116[i]-1.685;
    }
	

	double xmin=ax3116[0];
	double xmax=ax3116[num1-1];
	
    int bmin= h1Edep_3116->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_3116->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_3116->Integral(bmin,bmax)*h1Edep_3116->GetXaxis()->GetBinWidth(1);
    scale=1.0/integral;

	h1Edep_3116->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1-1; i++) {
        if ( ax3116[i] >= xmin && ax3116[i] <= xmax ) {
	   integral=integral+(ay3116[i+1]+ay3116[i])/2.0*(ax3116[i+1]-ax3116[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1;i++){
	ay3116[i]*= scale;
	meas1_3116->SetPoint(i, ax3116[i], ay3116[i]);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////	
	TFile fin_3514("/data/rice/guidata/shanghai-C-100M-351.4-Rifi.root");
	TH3F* edep = (TH3F *)fin_3514.Get("voxelEnergy");
    edep->GetXaxis()->SetRange(2,2);
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_3514 = (TH1 *)(edep->Project3D("z"));
	
	TFile fhis_3514("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_3514 = (TGraph *)fhis_3514.Get("351.4");
	
//    TFile fhis_3514("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
//    TGraph* meas1_3514 = (TGraph *)fhis_3514.Get("C_351.40");

    h1Edep_3514->GetXaxis()->SetLimits(0,500.0);
    h1Edep_3514->GetXaxis()->SetRange(1,6000);
    h1Edep_3514->SetStats(0);
	int num3514=meas1_3514->GetN();
	double ax3514[num3514+1], ay3514[num3514+1];
	
	for(int i=0; i<num3514; i++) {
    meas1_3514->GetPoint(i, ax3514[i], ay3514[i]); 
	ax3514[i] =ax3514[i]-1.685;
    }
	
	double xmin=ax3514[0];
	double xmax=ax3514[num3514-1];
	
    int bmin= h1Edep_3514->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_3514->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_3514->Integral(bmin,bmax)*h1Edep_3514->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep_3514->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num3514-1; i++) {
        if ( ax3514[i] >= xmin && ax3514[i] <= xmax ) {
	   integral=integral+(ay3514[i+1]+ay3514[i])/2.0*(ax3514[i+1]-ax3514[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num3514;i++){
	ay3514[i]*= scale;
	meas1_3514->SetPoint(i, ax3514[i], ay3514[i]);
    }
////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////
    TFile fin3982("/data/rice/guidata/shanghai-C-100M-398.2-Rifi.root");
	TH3F* edep = (TH3F *)fin3982.Get("voxelEnergy");
    edep->GetXaxis()->SetRange(2,2);
    iyMin = edep->GetYaxis()->FindBin(-40);
    iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_3982 = (TH1 *)(edep->Project3D("z"));
	
	TFile fhis3982("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_3982 = (TGraph*)fhis3982.Get("398.2");

    h1Edep_3982->GetXaxis()->SetLimits(0,500.0);
    h1Edep_3982->GetXaxis()->SetRange(1,6000);
	h1Edep_3982->SetStats(0);
    
	int num1=meas1_3982->GetN();
	double ax3982[num1+1], ay3982[num1+1];
	
	for(int i=0; i<num1; i++) {
    meas1_3982->GetPoint(i, ax3982[i], ay3982[i]); 
	ax3982[i] =ax3982[i]-1.685;
    }
	

	double xmin=ax3982[0];
	double xmax=ax3982[num1-1];
	
    int bmin= h1Edep_3982->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_3982->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_3982->Integral(bmin,bmax)*h1Edep_3982->GetXaxis()->GetBinWidth(1);
    scale=1.0/integral;

	h1Edep_3982->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1-1; i++) {
        if ( ax3982[i] >= xmin && ax3982[i] <= xmax ) {
	   integral=integral+(ay3982[i+1]+ay3982[i])/2.0*(ax3982[i+1]-ax3982[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1;i++){
	ay3982[i]*= scale;
	meas1_3982->SetPoint(i, ax3982[i], ay3982[i]);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////

    TFile fin_4301("/data/rice/guidata/shanghai-C-100M-430.1-Rifi.root");
	
	TFile fhis1_4301("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
    TGraph* meas1_4301 = (TGraph*)fhis1_4301.Get("430.1");
	
//    TFile fhis1_4301("/home/qw14/02_AnnualQA_1/20160212_TR1_annualQA/TR1_0212.root");
//    TGraph* meas1_4301 = (TGraph*)fhis1_4301.Get("C_430.10");
	
	TFile fhis2_4301("/home/qw14/02_AnnualQA_1/20160211_TR1_annualQA/TR1_0211.root");
    TGraph* meas2_4301 = (TGraph *)fhis2_4301.Get("C_430.1");

    TH3F* edep = (TH3F *)fin_4301.Get("voxelEnergy");

    edep->GetXaxis()->SetRange(2,2);
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep_4301 = (TH1 *)(edep->Project3D("z"));
    h1Edep_4301->GetXaxis()->SetLimits(0,500.0);
    h1Edep_4301->GetXaxis()->SetRange(1,6000);
	h1Edep_4301->SetStats(0);
	
	
	int num1_4301=meas1_4301->GetN();
	double ax1_4301[num1_4301+1], ay1_4301[num1_4301+1];
	
	for(int i=0; i<num1_4301; i++) {
    meas1_4301->GetPoint(i, ax1_4301[i], ay1_4301[i]); 
	ax1_4301[i] =ax1_4301[i]-1.685;
    }
	
	int num2_4301=meas2_4301->GetN();
	double ax2_4301[num2_4301+1], ay2_4301[num2_4301+1];
	for(int i=0; i<num2_4301; i++) {
    meas2_4301->GetPoint(i, ax2_4301[i], ay2_4301[i]); 
	ax2_4301[i] =ax2_4301[i]-1.685;
    }

	double xmin=ax1_4301[0];
	double xmax=ax1_4301[num1_4301-1];
	
	if (xmin<ax2_4301[0]){
	xmin=ax2_4301[0];
	}	
	
	if (xmax>ax2_4301[num2_4301-1]){
	xmax=ax2_4301[num2_4301-1];
	}
	
    int bmin= h1Edep_4301->GetXaxis()->FindBin(xmin);
	int bmax= h1Edep_4301->GetXaxis()->FindBin(xmax);

    double integral=h1Edep_4301->Integral(bmin,bmax)*h1Edep_4301->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep_4301->Scale(scale);
	
	double integral=0.0;

    for(int i=0; i<num1_4301-1; i++) {
        if ( ax1_4301[i] >= xmin && ax1_4301[i] <= xmax ) {
	   integral=integral+(ay1_4301[i+1]+ay1_4301[i])/2.0*(ax1_4301[i+1]-ax1_4301[i]);
        }
    }
	
	scale=1.0/integral;
	for (int i=0;i<num1_4301;i++){
	ay1_4301[i]*= scale;
	meas1_4301->SetPoint(i, ax1_4301[i], ay1_4301[i]);
    }
	
	double integral=0.0;
    for(int i=0; i<num2_4301-1; i++) {
		if ( ax2_4301[i] >= xmin && ax2_4301[i] <= xmax ) {
	integral=integral+(ay2_4301[i+1]+ay2_4301[i])/2.0*(ax2_4301[i+1]-ax2_4301[i]);
		}
    }
	
	scale=1.0/integral;
	
	for (int i=0;i<num2_4301;i++){
	ay2_4301[i]*= scale;
	meas2_4301->SetPoint(i,ax2_4301[i], ay2_4301[i]);
    }


///////////////////////////////////////////////////////////////////////

    int binmax = h1Edep_887->GetMaximumBin();
    h1Edep_887->GetXaxis()->SetRange(binmax-40,binmax+30);

    int binmax = h1Edep_1595->GetMaximumBin();
    h1Edep_1595->GetXaxis()->SetRange(binmax-40,binmax+30);

    int binmax = h1Edep_1957->GetMaximumBin();
    h1Edep_1957->GetXaxis()->SetRange(binmax-40,binmax+30);

    int binmax = h1Edep_2341->GetMaximumBin();
    h1Edep_2341->GetXaxis()->SetRange(binmax-40,binmax+30);

    int binmax = h1Edep_2689->GetMaximumBin();
    h1Edep_2689->GetXaxis()->SetRange(binmax-40,binmax+30);

    int binmax = h1Edep_3116->GetMaximumBin();
    h1Edep_3116->GetXaxis()->SetRange(binmax-40,binmax+30);

    int binmax = h1Edep_3514->GetMaximumBin();
    h1Edep_3514->GetXaxis()->SetRange(binmax-40,binmax+35);

    binmax = h1Edep_3982->GetMaximumBin();
    h1Edep_3982->GetXaxis()->SetRange(binmax-40,binmax+35);

    binmax = h1Edep_4301->GetMaximumBin();
    h1Edep_4301->GetXaxis()->SetRange(binmax-40,binmax+35);

///////////////////////////////////////////////////////////////////////////////////////////////////////////
    char hName[300];
//  sprintf(hName,"From left to Right, the energies are 88.7, 195.7, 268.9, 351.4, 430.1 MeV",i);
    sprintf(hName,"",i);
////////////////////////////////////////////////////////////////////////
    TCanvas* c1 = new TCanvas("Canvas","Canvas",10,10,990,660);	
    c1->Draw();
	
	c1->cd();
    TPad *pad887 =new TPad("pad887","pad887",0.0,0.67,0.33,1);

    pad887->Draw();
    pad887->cd();
	h1Edep_887->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_887->GetYaxis()->SetTitle("Dose(a.u.)");
	h1Edep_887->GetYaxis()->SetTitleOffset(1.5);
    h1Edep_887->Draw("L Hist");
    h1Edep_887->SetLineColor(1);
    h1Edep_887->SetLineWidth(2);
    h1Edep_887->SetTitle("88.8 MeV");
	
	meas1_887->Draw("p");
    meas1_887->SetMarkerStyle(20);
    meas1_887->SetMarkerSize(.4);
    meas1_887->SetMarkerColor(2);
	
/////////////////////////////////////////////////////////////////////////////	
	c1->cd();
    TPad *pad1595 =new TPad("pad1595","pad1595",0.34,0.67,0.66,1);
	pad1595->Draw();
    pad1595->cd();
	
    h1Edep_1595->Draw("L Hist");
    h1Edep_1595->SetLineColor(1);
    h1Edep_1595->SetLineWidth(2);
	h1Edep_1595->SetTitle("159.5 MeV");
    h1Edep_1595->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_1595->GetYaxis()->SetTitle("Dose(a.u.)");
    h1Edep_1595->GetYaxis()->SetTitleOffset(1.5);

    meas1_1595->Draw("p");
    meas1_1595->SetMarkerStyle(20);
    meas1_1595->SetMarkerSize(.4);
    meas1_1595->SetMarkerColor(2);	

/////////////////////////////////////////////////////////////////////////////
	
	c1->cd();
    TPad *pad1957 =new TPad("pad3514","pad3514",0.67,0.67,1,1);

    pad1957->Draw();
    pad1957->cd();
	h1Edep_1957->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_1957->GetYaxis()->SetTitle("Dose(a.u.)");
	h1Edep_1957->GetYaxis()->SetTitleOffset(1.5);
    h1Edep_1957->Draw("L Hist");
    h1Edep_1957->SetLineColor(1);
    h1Edep_1957->SetLineWidth(2);
	h1Edep_1957->SetTitle("195.7 MeV");
	
    meas1_1957->Draw("p");
    meas1_1957->SetMarkerStyle(20);
    meas1_1957->SetMarkerSize(.4);
    meas1_1957->SetMarkerColor(2);
	
/////////////////////////////////////////////////////////////////////////////	
	c1->cd();
    TPad *pad2341 =new TPad("pad2341","pad2341",0.0,0.34,0.33,0.66);

    pad2341->Draw();
    pad2341->cd();
    
	h1Edep_2341->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_2341->GetYaxis()->SetTitle("Dose(a.u.)");
    h1Edep_2341->Draw("L Hist");
    h1Edep_2341->SetLineColor(1);
    h1Edep_2341->SetLineWidth(2);
	h1Edep_2341->SetTitle("234.1 MeV");
	h1Edep_2341->GetYaxis()->SetTitleOffset(1.5);

    meas1_2341->Draw("p");
    meas1_2341->SetMarkerStyle(20);
    meas1_2341->SetMarkerSize(.4);
    meas1_2341->SetMarkerColor(2);	

/////////////////////////////////////////////////////////////////////////////////
	
    c1->cd();
    TPad *pad2689 =new TPad("pad2689","pad2689",0.34,0.34,0.66,0.66);

    pad2689->Draw();
    pad2689->cd();
    h1Edep_2689->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_2689->GetYaxis()->SetTitle("Dose(a.u.)");
	h1Edep_2689->GetYaxis()->SetTitleOffset(1.5);
    h1Edep_2689->Draw("L Hist");
    h1Edep_2689->SetLineColor(1);
    h1Edep_2689->SetLineWidth(2);
	h1Edep_2689->SetTitle("268.9 MeV");
	
	meas1_2689->Draw("p");
    meas1_2689->SetMarkerStyle(20);
    meas1_2689->SetMarkerSize(.4);
    meas1_2689->SetMarkerColor(2);
	
/////////////////////////////////////////////////////////////////////////////	
	c1->cd();
    TPad *pad3116 =new TPad("pad3116","pad3116",0.67,0.34,1,0.66);

    pad3116->Draw();
    pad3116->cd();
    
	h1Edep_3116->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_3116->GetYaxis()->SetTitle("Dose(a.u.)");
	
    h1Edep_3116->Draw("L Hist");
    h1Edep_3116->SetLineColor(1);
    h1Edep_3116->SetLineWidth(2);
    h1Edep_3116->SetTitle("311.6 MeV");
    h1Edep_3116->GetYaxis()->SetTitleOffset(1.5);
	
    meas1_3116->Draw("p");
    meas1_3116->SetMarkerStyle(20);
    meas1_3116->SetMarkerSize(.4);
    meas1_3116->SetMarkerColor(2);
////////////////////////////////////////////////////////////////////////////////////	

	c1->cd();
    TPad *pad3514 =new TPad("pad3514","pad3514",0.0,0.0,0.33,0.33);

    pad3514->Draw();
    pad3514->cd();
	h1Edep_3514->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_3514->GetYaxis()->SetTitle("Dose(a.u.)");
	h1Edep_3514->GetYaxis()->SetTitleOffset(1.5);
    h1Edep_3514->Draw("L Hist");
    h1Edep_3514->SetLineColor(1);
    h1Edep_3514->SetLineWidth(2);
    h1Edep_3514->SetTitle("351.4 MeV");
	
    meas1_3514->Draw("same p");
    meas1_3514->SetMarkerStyle(20);
    meas1_3514->SetMarkerSize(.4);
    meas1_3514->SetMarkerColor(2);

 //////////////////////////////////////////////////////////////////////////////////////// 

	c1->cd();
    TPad *pad3982 =new TPad("pad3982","pad3982",0.34,0.0,0.66,0.33);

    pad3982->Draw();
    pad3982->cd();
	h1Edep_3982->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_3982->GetYaxis()->SetTitle("Dose(a.u.)");
	h1Edep_3982->GetYaxis()->SetTitleOffset(1.5);
    h1Edep_3982->Draw("L Hist");
    h1Edep_3982->SetLineColor(1);
    h1Edep_3982->SetLineWidth(2);
    h1Edep_3982->SetTitle("398.2 MeV");
	
    meas1_3982->Draw("p");
    meas1_3982->SetMarkerStyle(20);
    meas1_3982->SetMarkerSize(.4);
    meas1_3982->SetMarkerColor(2);

 ////////////////////////////////////////////////////////////////////////////////////	

	c1->cd();
    TPad *pad4301 =new TPad("pad4301","pad4301",0.67,0.0,1.0,0.33);

    pad4301->Draw();
    pad4301->cd();
    h1Edep_4301->GetXaxis()->SetTitle("Depth(mm)");
    h1Edep_4301->GetYaxis()->SetTitle("Dose(a.u.)");
	h1Edep_4301->GetYaxis()->SetTitleOffset(1.5);
    h1Edep_4301->Draw("L Hist");
    h1Edep_4301->SetLineColor(1);
    h1Edep_4301->SetLineWidth(2);
    h1Edep_4301->SetTitle("430.1 MeV");

    meas1_4301->Draw("p");
    meas1_4301->SetMarkerStyle(20);
    meas1_4301->SetMarkerSize(.4);
    meas1_4301->SetMarkerColor(2);
 
 ////////////////////////////////////////////////////////////////////////////////////		


	
    if ( 1 ) return;	

}
