Tuning=/home/rice/phasespace-generator/TuningParameters/carbon/TuningParameter-C-depth

#nominalEnergies="88.8 110.6 159.5 195.7 227.9 234.1 257.6 268.9 285.4 311.6 336.8 351.4 384.4 398.2 430.1"
#nominalEnergies="88.8"
#nominalEnergies="88.8 110.6 159.5 195.7 234.1 268.9 311.6 351.4 398.2 430.1"
nominalEnergies="88.8 110.6 268.9 311.6 351.4 398.2 430.1"

foci="2"

eng=1

inputFile=parameter-carbon-eng$eng-depth.out

if [ -e $inputFile ] ; then
   \rm $inputFile
fi

for focus in $foci; do

for nominalEnergy in $nominalEnergies ; do
   $Tuning $nominalEnergy $focus $eng > temp.txt
    nominalEnergyRound=$(cat temp.txt | tail -n 1 | cut -d':' -f1)
    realEnergy=$(cat temp.txt | tail -n 1 | cut -d':' -f2)
    Energywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f3)
    xwidth=$(cat temp.txt | tail -n 1 | cut -d':' -f4)
    ywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f5)
    cxwidth=$(cat temp.txt | tail -n 1 | cut -d':' -f6)
    cywidth=$(cat temp.txt | tail -n 1 | cut -d':' -f7)

cat >> $inputFile << EOF
  $nominalEnergyRound $realEnergy $Energywidth $xwidth $ywidth $cxwidth $cywidth
EOF
cp temp.txt temp-$nominalEnergy-$focus.txt
#rm -rf /data/rice/phasespace/Shanghai-$nominalEnergyRound.bin
#rm -rf /data/rice/guidata/shanghai-100M-$nominalEnergyRound.root
rm -rf /data/rice/guidata/shanghai-lateral-100M-$nominalEnergyRound-x.root
rm -rf /data/rice/guidata/shanghai-lateral-100M-$nominalEnergyRound-y.root
 done
done
