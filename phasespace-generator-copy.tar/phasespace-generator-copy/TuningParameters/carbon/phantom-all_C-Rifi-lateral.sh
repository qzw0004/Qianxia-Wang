#!/bin/bash

doseR=""
doseW=0
dose=0
edep=0
layer=all
LET=0
nGpuBlocks=5000
nGpuThreads=100
nGpus=0
nhistories=1
nThreads=40

particle=C12
verbose=1
projection=x

while getopts ab:c:d:e:f:p:g:hi:j:k:l:m:n:o:p:q:r:s:trv:y:wz: flag
do
  case $flag in
    d) dose=1 ;;
    e) edep=1 ;;
    f) particle=$OPTARG;;
    p) projection=$OPTARG ;;
    g) nGpus=$OPTARG ;;
    h) echo "HELP "
       echo "phantom-all.sh   -h : print this help "
       echo "                 -d : Write dose-to-tissue   "
       echo "                 -e : Write deposited energy "
       echo "                 -g : # GPU units "
       echo "                 -i : # GPU blocks "
       echo "                 -j : # GPU threads "
       echo "                 -n : Number of histories "
       echo "                 -r : Write RBE Weighted Dose "
       echo "                 -t : Write LET               "
       echo "                 -v : Verbose level   "
       echo "                 -w : Write dose-to-wate     "
       echo "                 -z : Number of threads "
       exit
     ;;
    i) nGpuBlocks=$OPTARG ;;
    j) nGpuThreads=$OPTARG ;;
    n) nhistories=$OPTARG ;;
    q) nominalEnergy=$OPTARG ;;
    r) doseR=$OPTARG ;;
    t) LET=1 ;;
    v) verbose=$OPTARG ;;
    w) doseW=1 ;;
    z) nThreads=$OPTARG ;;
        ?) exit ;;
  esac
done

shift $(( OPTIND - 1 ))  # shift past the last flag or argument


if [[ $nhistories == *"M" ]]; then
   nkhistories=$nhistories
   nhistories=${nkhistories:0:${#nkhistories}-1}
   nhistories=$[$nhistories*1000000]
elif [[ $nhistories == *"K" ]]; then
   nkhistories=$nhistories
   nhistories=${nkhistories:0:${#nkhistories}-1}
   nhistories=$[$nhistories*1000]
else
   if [ $nhistories -gt 999999 ] ; then
      nkhistories=$[$nhistories/1000000]M
   elif [ $nhistories -gt 999 ] ; then
      nkhistories=$[$nhistories/1000]K
   elif [ $nhistories -gt 0 ] ; then
      nkhistories=$nhistories
   else
      nkhistories=all
   fi
fi

if (( nGpus > 0 )) ; then
   executable=/home/rice/fdc/fdc-v51s-wrk3/fdc-gpu-prod
   engine=gpu
else 
   executable=/home/rice/fdc/fdc-v51s-wrk3/fdc-cpu-prod
   engine=cpu
fi

echo verbose $verbose

FDCDATA=/data/fdcdata
DatabaseFile=$FDCDATA/db-FTFP_BERT-C12-h2o-oneblock-6000MeV-100K-iso-sep2018-thread-0-supercleaned.bin
MaterialHistosFile=$FDCDATA/g4IonFdcParameters-Idef-FTFP_BERT-sphic.root
BeamFile=/data/rice/phasespace/Shanghai-$nominalEnergy-Rifi.bin
#BeamFile=/data/rice/phasespace/carbon/3mm-Rifi-foci-1/Shanghai-$nominalEnergy.bin

jobName=shanghai-C-lateral-$nkhistories
logFile=$jobName.log
if [ -e $logFile ] ; then
   \rm $logFile
fi

latticeFile=/home/rice/fdc/commisioning/fdc-v50-lateral-X/lattice-air-xseg-sphic-$projection.root
analysisFile=/data/rice/guidata/$jobName-$nominalEnergy-Rifi-$projection.root



controlFile=$jobName.control
if [ -e $controlFile ] ; then
   \rm $controlFile
fi

cat >> $controlFile << EOF
Verbose_level               $verbose
Number_of_histories         $nhistories
Number_Threads              $nThreads
Number_GpuThreads           $nGpuThreads
Number_GpuBlocks            $nGpuBlocks
Number_GPUS                 $nGpus
Analysis_file               $analysisFile
Acceptable_Mean_Error       0.35
Freq_Check_Mean_Error       1000000
Phantom_file                $latticeFile
Phantom_histogram_name	    patientGeo
Beam_direction              0. 0. 1.
Beam_phantom_entry          0.0 0.0 -1125.8.
Beam_file                   $BeamFile
Gantry_angle                0.001
Dose_in_Gy                  1
Write_LET                   $LET
Write_DoseW                 $doseW
Write_DoseR                 $doseR
Material_Histos_file        $MaterialHistosFile
Database_file               $DatabaseFile
EOF

echo "Start Program Execution "
$executable -f $controlFile
\rm $controlFile
