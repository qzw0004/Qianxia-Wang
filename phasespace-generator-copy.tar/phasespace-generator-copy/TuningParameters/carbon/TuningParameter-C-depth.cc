#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cmath>
#include <iostream>
#include <complex>
#include <cstdlib>
#include <fstream>
#include "TRandom.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TFile.h"
#include "TMath.h"
#include "TGraph.h"
#include <errno.h>
#include <stdlib.h>
#include "TCanvas.h"
#include "TColor.h"
#include "TFile.h"
#include "TTree.h"
#include "TGraph.h"
#include "TPRegexp.h"
#include <TROOT.h>
#include <TSystem.h>
#include "TString.h"
#include "TStopwatch.h"
#include "TApplication.h"

using namespace std;

//==================================================================================================
int main(int argc, char *argv[]) {
//**************************************************************************************************
// Measurement
//**************************************************************************************************	

//measurement reading
     float nominalEnergy=86.2;
     if ( argc > 1 ) nominalEnergy=atof(argv[1]);

     int focus=1;
     if ( argc > 2 ) focus=atoi(argv[2]);
    
     int eng=1;
     if ( argc > 3 ) eng=atoi(argv[3]);
	 
	 char energyName[300];
	 
	 if (nominalEnergy<100.0) sprintf (energyName, "%4.1f", nominalEnergy);
	 else sprintf (energyName, "%5.1f", nominalEnergy);
	 
	 printf("a%sa\n", energyName);

//    TFile fhis1("/data/rice/DDD-data/Carbon-scale-3mm.root");
     TFile fhis1("/data/qwang11/SPHIC-Spot-data/3mmRifi.root");
	 
     TGraph* meas = (TGraph*)fhis1.Get(energyName);//????????????????????????????????????????

     if ( meas == NULL ) {
       printf("meas not found \n" );
       return 0 ;
     }

     int num=meas->GetN();
     double ax1[num+1], ay1[num+1];
     int looplimit=35;
	
     for(int i=0; i<num; i++) {
        meas->GetPoint(i, ax1[i], ay1[i]); 
     }
	
//end of measurement reading

//normalization and finding peak for measurement

    for (int i=0;i<num;i++){
       ax1[i]=ax1[i]-1.685;
       meas->SetPoint(i, ax1[i], ay1[i]);
     }
	
    double xmin=ax1[0];
    double xmax=ax1[num-1];
     
     printf("xmin %f xmax %f\n",xmin,xmax);
	 
     double integral=0.0;
     
     for(int i=0; i<num-1; i++) {
        if ( ax1[i] >= xmin && ax1[i] <= xmax ) {
	    integral=integral+(ay1[i+1]+ay1[i])/2.0*(ax1[i+1]-ax1[i]);
        }
     }
	
	 float scale=1.0/integral;
	 
     for(int i=0; i<num; i++){
	 ay1[i]*= scale;
	 meas->SetPoint(i, ax1[i], ay1[i]);
     }
	
// end of normalization and finding peak for measurement

	 double PeakMea=0.0;
	 double PeakMeaPos;
	 int ihalf;
	 float Scaling =0.65;
	 for(int i=0; i<num; i++)
	 {
	     if(ay1[i]>PeakMea)
	     {
	     PeakMea = ay1[i];
	     PeakMeaPos=ax1[i];
         ihalf=i;
	     }
	 }
// end of normalization and finding peak for measurement


//peak position and FWHM for measuremnt

     double deltaY=10000000;
	 double halfHL, halfHPositionL;
	 for(int i=0; i<ihalf; i++){
		 double deltaYY=abs(ay1[i]-Scaling*PeakMea);
	     if(deltaYY<deltaY)
	     {
		 deltaY=deltaYY; 
	     halfHL = ay1[i];
	     halfHPositionL=ax1[i];
	     }
	 }
	 
	 deltaY=10000000;
	 double halfHR, halfHPositionR;
	 
	 for(int i=ihalf; i<num; i++){
		 double deltaYY=abs(ay1[i]-Scaling*PeakMea);
	     if(deltaYY<deltaY)
	     {
		 deltaY=deltaYY; 
	     halfHR = ay1[i];
	     halfHPositionR=ax1[i];
	     }
	 }

	double fwhmMea = halfHPositionR-halfHPositionL;
	
//**************************************************************************************************
// End of Measurement
//**************************************************************************************************

    float realEnergy  = 12*nominalEnergy;
	float EnergyWidth = 12*2;
	
	string str1="/home/rice/phasespace-generator/description_of_beam/description-C-s.sh";
	string str2="/home/rice/phasespace-generator/TuningParameters/carbon/phantom-all_C-Rifi.sh";
	
	char variable1[300];
	char variable2[300];
	char variableLx[300];
	char variableLy[300];
	char CalName[300];
	char CalNamex[300];
	char CalNamey[300];
        char hName[300];
        float deltaEnergy;
	float deltaFWHMe;
	float ratio=12*0.5;
	float ratioE=12;
	float ratioEo=ratioE;
	float ratioo=ratio;
	float NewFWHMe;
	int nnn=0;
	int nnE=0;
	int nnEw=0;
	
	float  fwhmCalO    ; 
	float  fwhmMeaO    ;
	float  PeakCalPosO ;
	float  PeakMeaPosO ;
	int sign;
	int IIIIII=0;
	float bestEnergyWidth, bestRealEnergy;
	
//	for (; ;){
    for (int j=1; j<20; j++){
	IIIIII++;
    if (nominalEnergy<100) 	sprintf(variable1, " -n %4.1f -e %f -f %f\n", nominalEnergy, realEnergy, EnergyWidth);
    else 	sprintf(variable1, " -n %5.1f -e %f -f %f\n", nominalEnergy, realEnergy, EnergyWidth);

	string Ph= str1 + variable1;
	const char *command1 = Ph.c_str();
	printf("%s\n", command1);
    system(command1);
	
	if (nominalEnergy<100) sprintf(variable2, " -n 100M -g %i -q %4.1f\n", eng, nominalEnergy);
    else 	sprintf(variable2, " -n 100M -g %i -q %5.1f\n", eng, nominalEnergy);
	
	string FDC= str2 + variable2;
	const char *command2 = FDC.c_str();
	printf("%s\n", command2);
    system(command2);
   
    if (nominalEnergy<100.0) sprintf(CalName,"/data/rice/guidata/shanghai-C-100M-%4.1f-Rifi.root",nominalEnergy);
    else                     sprintf(CalName,"/data/rice/guidata/shanghai-C-100M-%5.1f-Rifi.root",nominalEnergy);

// Calculation projected in z

   TFile fin(CalName);
   
//   printf("%s\n", CalName);
	
   TH3F* edep = (TH3F *)fin.Get("voxelEnergy");

   if ( edep == NULL ) {
      printf("edep not found \n" );
      return(1) ;
   }

    printf("edep %p\n", edep );

    int ixMin = edep->GetXaxis()->FindBin(-40);
    int ixMax = edep->GetXaxis()->FindBin(40);
	
    printf("ixMin %d ixMax %d\n", ixMin, ixMax);
	
    edep->GetXaxis()->SetRange(ixMin,ixMax);
	
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
	
    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
	
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep = (TH1F *)(edep->Project3D("z"));

    h1Edep->GetXaxis()->SetLimits(0, 500.0);
	
// end of calculation projected in z

//*************************************************************************************************************
//
//*************************************************************************************************************

//normalization and finding peak for calculation

    int bmin= h1Edep->GetXaxis()->FindBin(xmin);
    int bmax= h1Edep->GetXaxis()->FindBin(xmax);

    double integral=h1Edep->Integral(bmin,bmax)*h1Edep->GetXaxis()->GetBinWidth(1);
    double scale=1.0/integral;

	h1Edep->Scale(scale);
	
//end of normalization and finding peak for calculation	

//*************************************************************************************************************
//
//*************************************************************************************************************

	double PeakCal=h1Edep->GetBinContent(h1Edep->GetMaximumBin());
	double PeakCalPos=h1Edep->GetXaxis()->GetBinCenter(h1Edep->GetMaximumBin());

//check FWHM

     float y = Scaling*PeakCal;
	 
     int bin1 = h1Edep->FindFirstBinAbove(y);
     int bin2 = h1Edep->FindLastBinAbove(y);
	 
     double fwhmCal = h1Edep->GetBinCenter(bin2)-h1Edep->GetBinCenter(bin1);
	
     cout<<"1111111111111111111111111111111111111111111111 "<<PeakCalPos<<", "<<PeakMeaPos<<endl;
     cout<<"1111111111111111111111111111111111111111111111 "<<abs(PeakCalPos-PeakMeaPos)<<endl;
     cout<<"2222222222222222222222222222222222222 "<<fwhmCal<<", "<<fwhmMea<<endl;
     cout<<"222222222222222222222222222222222222222 "<<abs(fwhmCal-fwhmMea)<<endl;
   
     if (abs(PeakCalPos-PeakMeaPos)>0.05){
		 nnE=nnE+1;
	     if (nnE>1){
		 
		      if ((PeakCalPosO-PeakMeaPosO)*(PeakCalPos-PeakMeaPos)>0.0) ratio=1.25*ratio;
			  else       ratio=1/1.25*ratio;
         } 
		  else ratio=ratioo;
		  
	    for (; ;){
	         deltaEnergy = ratio*(PeakMeaPos-PeakCalPos);
	         if ((realEnergy+deltaEnergy)<=0.0) ratio=0.5*ratio;
		     else break;
	     }
		 
	 }
      else 
	  {nnE=0;
	  deltaEnergy=0.0;
	  }
	  
      realEnergy=realEnergy+deltaEnergy;
      
	  if(abs(fwhmCal-fwhmMea)/fwhmMea>0.15){
		  nnEw=0;
		 if ((fwhmCal-fwhmMea)>0.0) sign=-1;
		 else                      sign=1;
         deltaFWHMe=sign*0.5*EnergyWidth;  
	  }
	  else{
	        if (abs(fwhmCal-fwhmMea)/fwhmMea>0.001){
	        	 nnEw=nnEw+1;
	        	 if(nnEw>1)
	        	 {
                    if((fwhmCalO-fwhmMeaO)*(fwhmCal-fwhmMea)>0.0) ratioE=1.25*ratioE;
                    else          ratioE=1/1.25*ratioE;  			 
	             }
	        	  
	        	  else ratioE=ratioEo;
	        	  
	        	 deltaFWHMe = ratioE*(fwhmMea-fwhmCal)/fwhmMea;
	            }
	        else{
	        	 nnEw=0;
	        	 deltaFWHMe= 0.0;
	            }
	  }       	 
	        	  EnergyWidth = EnergyWidth + deltaFWHMe;
	        	  if (EnergyWidth<0.03){
	        		  deltaFWHMe=0.0;
	        	      EnergyWidth= 0.03;}
	
		 
		 fwhmCalO    = fwhmCal;
		 fwhmMeaO    = fwhmMea;
		 PeakCalPosO = PeakCalPos;
		 PeakMeaPosO = PeakMeaPos;
		 
     if (abs(PeakCalPos-PeakMeaPos)<0.2 && abs(fwhmCal-fwhmMea)/fwhmMea<0.001){
         cout<<"standard is satisfied"<<endl;
	 break;
     }
	 if (abs(deltaEnergy)<0.1 && abs(deltaFWHMe) < 0.1) {
         nnn=nnn+1;
         cout<<"NNNNNNNNNN"<<nnn<<endl;
         }
         else nnn=0;
	 
	 if (nnn>2) break;

   }
   
   // Calculation projected in z

   TFile fin(CalName);
   
//   printf("%s\n", CalName);
	
   TH3F* edep = (TH3F *)fin.Get("voxelEnergy");

  if ( edep == NULL ) {
      printf("edep not found \n" );
      return(1) ;
   }

    printf("edep %p\n", edep );

    int ixMin = edep->GetXaxis()->FindBin(-40);
    int ixMax = edep->GetXaxis()->FindBin(40);
	
//    printf("ixMin %d ixMax %d\n", ixMin, ixMax);
	
    edep->GetXaxis()->SetRange(ixMin,ixMax);
	
    int iyMin = edep->GetYaxis()->FindBin(-40);
    int iyMax = edep->GetYaxis()->FindBin(40);
	
//    printf("iyMin %d iyMax %d\n", iyMin, iyMax);
	
    edep->GetYaxis()->SetRange(iyMin,iyMax);
 
    TH1F* h1Edep = (TH1F *)(edep->Project3D("z"));

    h1Edep->GetXaxis()->SetLimits(0, 500.0);
	
// end of calculation projected in z

//*************************************************************************************************************
//
//*************************************************************************************************************

//normalization and finding peak for calculation

    int bmin= h1Edep->GetXaxis()->FindBin(xmin);
    int bmax= h1Edep->GetXaxis()->FindBin(xmax);

    integral=h1Edep->Integral(bmin,bmax)*h1Edep->GetXaxis()->GetBinWidth(1);
    scale=1.0/integral;

	h1Edep->Scale(scale);
	
//end of normalization and finding peak for calculation	

    TCanvas* c1 = new TCanvas(hName,hName, 800, 800 );
    c1->SetRightMargin(0.2);

    h1Edep->SetMarkerStyle(21);
    h1Edep->SetMarkerSize(1.0);
    h1Edep->Draw("L Hist");
    h1Edep->SetLineColor(1);
    h1Edep->SetLineWidth(2);
    h1Edep->SetMarkerColor(1);
    h1Edep->SetMarkerSize(2.0);
    h1Edep->SetStats(0);

    meas->Draw("p");
    meas->SetMarkerStyle(20);
    meas->SetMarkerSize(.4);
    meas->SetMarkerColor(2);

    if (nominalEnergy<100) sprintf(hName, "%4.1f MeV\n", nominalEnergy);
    else        sprintf(hName, "%5.1f MeV\n", nominalEnergy);


    if (nominalEnergy<100) sprintf(hName, "%4.1fMeV.pdf\n", nominalEnergy);
    else        sprintf(hName, "%5.1fMeV.pdf\n", nominalEnergy);

//    c1->SaveAs(hName);

  //End of calculating raw opening angles in x and y
	 
   if (nominalEnergy<100.0){
   printf("%4.1f:%f:%f\n",nominalEnergy,realEnergy,EnergyWidth);}
   else {
   printf("%5.1f:%f:%f\n",nominalEnergy,realEnergy,EnergyWidth);} 

   return 0;

}
