#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cmath>
#include <iostream>
#include <complex>
#include <cstdlib>
#include <fstream>
#include "TRandom.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TH3F.h"
#include "TFile.h"
#include "TMath.h"
#include "TGraph.h"

using namespace std;

//==================================================================================================
int main(int argc, char *argv[]) {
//**************************************************************************************************
// Measurement
//**************************************************************************************************	

//measurement reading
     float nominalEnergy=86.2;
     if ( argc > 1 ) nominalEnergy=atof(argv[1]);

     int focus=1;
     if ( argc > 2 ) focus=atoi(argv[2]);
    
     int eng=1;
     if ( argc > 3 ) eng=atoi(argv[3]);
	 
	 char energyName[300];
	 
	 if (nominalEnergy<100.0) sprintf (energyName, "%4.1f", nominalEnergy);
	 else sprintf (energyName, "%5.1f", nominalEnergy);
	 
	 printf("a%sa\n", energyName);
	
     char variable1[300];
	 char variable2[300];
	 char variableLx[300];
	 char variableLy[300];
	 char CalName[300];
	 char CalNamex[300];
	 char CalNamey[300];
         float deltaEnergy;
	 float deltaFWHMe;
	 float ratio=12*0.5;
	 float ratioE=10;
	 float ratioEo=ratioE;
	 float ratioo=ratio;
	 int nnn=0;
	 int nnE=0;
	 int nnEw=0;
	 int sign;
         int looplimit=35;        

    float realEnergy, EnergyWidth; 
	
 // Interpolate energy shift and energy width

   int nCol=3;

   char parameterFile[300];
	 
   ifstream file2, file3;

   sprintf(parameterFile,"/home/rice/phasespace-generator/TuningParameters/carbon/parameter-depth.dat");

   file2.open(parameterFile,ios::in);
   float Data1[nCol+1];
   int n=0;
   string line1;

   if(!file2.is_open())
    {
        cout<<"It failed"<<endl;
        return 0;
    }

    while(getline(file2,line1))
      n++;

    file2.close();

  double x[n+1], y[n+1], yew[n+1];
 
  int k=0;

  file3.open(parameterFile,ios::in);
 
    for (int j=0; j<n; j++)
    {
         for (int i=1; i<=nCol; i++){
         file3>>Data1[i];    
         }
              x[j] =Data1[1];
              y[j] =Data1[2]/12.0-Data1[1];
              yew[j] = Data1[3];
    }
  
//For ennergy shift
  TGraph *g = new TGraph(n, x, y);
  g->SetName("Energy shift");
  TGraph *gew = new TGraph(n, x, yew);
  gew->SetName("Energy distribution");

   realEnergy = 12*(g->Eval(nominalEnergy)+nominalEnergy); 
   EnergyWidth = gew->Eval(nominalEnergy);
   cout<<realEnergy<<", "<<EnergyWidth<<endl;
// end of interpolating energy shift and energy width
	
   string str1="/home/rice/phasespace-generator/description_of_beam/description-C-s.sh";

//**********************************************************************************************************************************************************  
//   
// Lateral parameters tuning 
//
//**********************************************************************************************************************************************************

   // Read measured FWHM at different depths   
   
   nCol=8; 
   
   ifstream file, file1;
   TString fileName="Lateral-FWHM-total-carbon";
   file.open(fileName,ios::in);
   float data;
   n=0;
   string line;
   
   if(!file.is_open())
    {
        cout<<"It failed"<<endl;
        return 0;
    } 

    while(getline(file,line))
      n++;

//    cout<<"n"<<n<<endl;
 
    file.close();
	
    float FWHM_m[3][6];
    float FWHM_c[3][6];
    float Data[100];
	int times=0;
	file1.open(fileName,ios::in);
	for (int j=1; j<=n; j++){
         for (int i=1; i<=nCol; i++){
         file1>>Data[i];
         }
		 int Fo=Data[2];
		 int Ax=Data[3];
		 if(abs(Data[1]-nominalEnergy)<0.1 & Fo== focus){
			 times++;
			 for (int i=4; i<=8; i++){
			 if(Ax == 1) {FWHM_m[1][i-3]=Data[i];
//			 cout<<"x = "<<FWHM_m[1][i-3]<<endl;
			 }
			 if(Ax == 2) {FWHM_m[2][i-3]=Data[i];
			 cout<<"y = "<<FWHM_m[2][i-3]<<endl;}
			 }
		 }
		 if (times == 2) break;
    }
	 file1.close();

	// end of reading measured FWHM at different depths
	
 	 string str3="/home/rice/phasespace-generator/TuningParameters/carbon/phantom-all_C-Rifi-lateral.sh";
	    if (nominalEnergy<100) sprintf(variableLx, " -n 100M -g %i -q %4.1f -p x\n", eng, nominalEnergy);
    else        sprintf(variableLx, " -n 100M -g %i -q %5.1f -p x\n", eng, nominalEnergy);

        if (nominalEnergy<100) sprintf(variableLy, " -n 100M -g %i -q %4.1f -p y\n", eng, nominalEnergy);
    else        sprintf(variableLy, " -n 100M -g %i -q %5.1f -p y\n", eng, nominalEnergy); 


	 char variable3[300];
	 char variable4[300];
	 float xWidth=0.1;  
	 float yWidth=0.1;
	 float cxWidth=0.01;
     float cyWidth=0.01;
	 
	 int nZpos=5;
     float* zPos = new float[nZpos];

	  
     zPos[0]=-800.0;
     zPos[1]=-400.0;
     zPos[2]=-0.0;
     zPos[3]=200.0;
     zPos[4]=600.0;
	
	 int nx = 3;
     int ny = 2;

     float dist1 = zPos[2]-zPos[1];
	 float dist2 = zPos[3]-zPos[2];
	 float dist3 = zPos[4]-zPos[3];
	 float dist4 = zPos[5]-zPos[4];
	 
     float graxm1=(FWHM_m[1][2]-FWHM_m[1][1])/(dist1*1.0);
	 float graxm2=(FWHM_m[1][3]-FWHM_m[1][2])/(dist2*1.0);
	 float graxm3=(FWHM_m[1][4]-FWHM_m[1][3])/(dist3*1.0);
	 float graxm4=(FWHM_m[1][5]-FWHM_m[1][4])/(dist4*1.0);
	 
	 float graxmB=(graxm1+graxm2+graxm3+graxm4)/4.0;
	 
	 float graym1=(FWHM_m[2][2]-FWHM_m[2][1])/(dist1*1.0);
	 float graym2=(FWHM_m[2][3]-FWHM_m[2][2])/(dist2*1.0);
	 float graym3=(FWHM_m[2][4]-FWHM_m[2][3])/(dist3*1.0);
	 float graym4=(FWHM_m[2][5]-FWHM_m[2][4])/(dist4*1.0);
	 
	 float graymB=(graym1+graym2+graym3+graym4)/4.0;
	 
     int mmm=0;
     int mmmm=0;
     int mmmmm=0;
	 
	 int nnx1=0;
	 int nny1=0;
	 int nnx2=0;
	 int nny2=0;
	 int nnx3=0;
	 int nny3=0;
	 int nnx5, nny5;
	 int nnxL=0;
	 int nnyL=0;
	 
     float deltaWidthcx, deltaWidthcy, deltaWidthx, deltaWidthy;
	 
//	 float para=sqrt(sqrt(150.1/nominalEnergy));
     float para=1.0;
 //        cout<<"AAAAAAAAAAAAAAAAAAAAAAAAAA para= "<<para<<endl;
	 float ratiocx=0.0025;
	 float ratiocy=0.0025;
	 float ratiocxo=ratiocx;
	 float ratiocyo=ratiocy;
	 float ratiox=0.025;
	 float ratioy=0.025;
	 float ratioxo=ratiox;
	 float ratioyo=ratioy;
	 
	 float gradixcO;
	 float gradixmO;
	 float gradiycO;
	 float gradiymO;
	 float FWHMxcO ;
	 float FWHMxcO1 ;
	 float FWHMycO ;
	 float FWHMycO1 ;
	 float Standard=0.0;
	 
//  calculating raw opening angles in x and y

    int kkkkk=0;
    float best=1000000;
    float bestxWidth ;
    float bestyWidth ;
    float bestcxWidth;
    float bestcyWidth;
    float limitx1=1.5;
    float limitx1O=limitx1;
    float limity1=1.5;
    float limity1O=limity1;
    float limit2=0.025; //difference at the 1st position
	float limit5=limit2; //difference at the 2nd position
	float limit6=limit2; //difference at the 4th position
    float limit3=0.02; //difference at the isocenter
	float limit4o=0.03; //gradient difference
	float limit4x=limit4o; //gradient difference
	float limit4y=limit4o; //gradient difference
//    float weight1=0.19;
//    float weight3=5.0/42.0;
      float weight3=1.0/6.0;
//    float weight2=4.0/42.0;
      float weight2=1.0/12.0;
//    float weight4=4.0/42.0;
      float weight4=1.0/12.0;

	
    float con1, con2, con3, con4, con5, con6, con7, con8, con9, con10, con11, con12;


   for (; ;){
	 
     kkkkk=kkkkk+1;
	 cout<<"KKKKKKKKKKKKKKKKKKKKKKKKKKKK = "<<kkkkk<<endl;
	 
     sprintf(variable3, " -n %4.1f -e %f -f %f -x %f -y %f -c %f -d %f\n", nominalEnergy, realEnergy, EnergyWidth, xWidth, yWidth, cxWidth, cyWidth);
	 
	 string Ph1= str1 + variable3;
	 const char *command3 = Ph1.c_str();
	 printf("%s\n", command3);
     system(command3);
	 
	 string FDCLx= str3 + variableLx;
	 const char *commandLx = FDCLx.c_str();
	 
	 printf("%s\n", commandLx);
     system(commandLx);
	 
	 string FDCLy= str3 + variableLy;
	 const char *commandLy = FDCLy.c_str();
     
	 printf("%s\n", commandLy);
     system(commandLy);
     
     if (nominalEnergy<100.0) sprintf(CalName,"/data/rice/guidata/shanghai-C-lateral-100M-%4.1f-Rifi-x.root",nominalEnergy);
     else                     sprintf(CalName,"/data/rice/guidata/shanghai-C-lateral-100M-%5.1f-Rifi-x.root",nominalEnergy);
     if (nominalEnergy<100.0) sprintf(CalNamey,"/data/rice/guidata/shanghai-C-lateral-100M-%4.1f-Rifi-y.root",nominalEnergy);
     else                     sprintf(CalNamey,"/data/rice/guidata/shanghai-C-lateral-100M-%5.1f-Rifi-y.root",nominalEnergy);

	 
     TFile finL(CalName);
	  
     TH3F* edepL = (TH3F *)finL.Get("voxelEnergy");
     
     if ( edepL == NULL ) {
        printf("edepL not found \n" );
        return(1) ;
     }

    printf("edepL %p\n", edepL );
	
	//calculate FWHM projected in x at different depths

   for (int i=0;i<nZpos;i++){
	  
     float z = zPos[i];
     int izMin = edepL->GetZaxis()->FindBin(z);
     int izMax = edepL->GetZaxis()->FindBin(z);
     printf("izMin %d izMax %d\n", izMin, izMax );
     edepL->GetZaxis()->SetRange(izMin,izMax);
     int iyMin = edepL->GetYaxis()->FindBin(0.0);
     int iyMax = edepL->GetYaxis()->FindBin(0.0);
     printf("iyMin %d iyMax %d\n", iyMin, iyMax );
     edepL->GetYaxis()->SetRange(iyMin,iyMax); 
     TH1F* h1EdepL = (TH1F *)(edepL->Project3D("x"));
	 
     int binmax = h1EdepL->GetMaximumBin();
     float y = 0.5*h1EdepL->GetBinContent(binmax);

     int bin1 = h1EdepL->FindFirstBinAbove(y);
     int bin2 = h1EdepL->FindLastBinAbove(y);
     FWHM_c[1][i+1] = h1EdepL->GetBinCenter(bin2)-h1EdepL->GetBinCenter(bin1);
	 
	 printf("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAFWHM_m_x FWHM_c_x %4.1f %4.1f\n", FWHM_m[1][i+1], FWHM_c[1][i+1]);
     
  }
     //end of calculating FWHM projected in x at different depth
	 
	 TFile finLy(CalNamey);
	 TH3F* edepLy = (TH3F *)finLy.Get("voxelEnergy");
     
     if ( edepLy == NULL ) {
        printf("edepLy not found \n" );
        return(1) ;
     }

    printf("edepLy %p\n", edepLy );
	
	//calculate FWHM projected in y at different depths

   for (int i=0;i<nZpos;i++){
	  
     float z = zPos[i];
     int izMin = edepLy->GetZaxis()->FindBin(z);
     int izMax = edepLy->GetZaxis()->FindBin(z);
     printf("izMin %d izMax %d\n", izMin, izMax );
     edepLy->GetZaxis()->SetRange(izMin,izMax);
     int ixMin = edepLy->GetXaxis()->FindBin(0.0);
     int ixMax = edepLy->GetXaxis()->FindBin(0.0);
     printf("iyMin %d iyMax %d\n", ixMin, ixMax );
     edepLy->GetXaxis()->SetRange(ixMin,ixMax); 
     TH1F* h1EdepLy = (TH1F *)(edepLy->Project3D("y"));
	 
     int binmax = h1EdepLy->GetMaximumBin();
     float y = 0.5*h1EdepLy->GetBinContent(binmax);

     int bin1 = h1EdepLy->FindFirstBinAbove(y);
     int bin2 = h1EdepLy->FindLastBinAbove(y);
     FWHM_c[2][i+1] = h1EdepLy->GetBinCenter(bin2)-h1EdepLy->GetBinCenter(bin1);
	 
	 printf("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFWHM_m_y FWHM_c_y %4.1f %4.1f\n", FWHM_m[2][i+1], FWHM_c[2][i+1]);
     
  }
     //end of calculating FWHM projected in y at different depths
	 
	 
	 
//*************************************************************************************************************
//
//*************************************************************************************************************
	       
	  float gradixc = FWHM_c[1][5]/(FWHM_c[1][1]*1.0+0.00001);
	  float gradixm = FWHM_m[1][5]/(FWHM_m[1][1]*1.0);
//	  float deltaGradix=(gradixc-gradixm)/gradixm;
	  
	  float XratioCM3= FWHM_c[1][3]/(FWHM_m[1][3]*1.0) ;
	  float XratioCM1= FWHM_c[1][1]/(FWHM_m[1][1]*1.0);
	  
	  float gradiyc = FWHM_c[2][5]/(FWHM_c[2][1]*1.0+0.000001);
	  float gradiym = FWHM_m[2][5]/(FWHM_m[2][1]*1.0);
	  
	  float YratioCM3= FWHM_c[2][3]/(FWHM_m[2][3]*1.0) ;
	  float YratioCM1= FWHM_c[2][1]/(FWHM_m[2][1]*1.0);
      
      con1=abs(FWHM_c[1][2]-FWHM_m[1][2])/FWHM_m[1][2];
	  con2=abs(FWHM_c[2][2]-FWHM_m[2][2])/FWHM_m[2][2];
	  
      con3=abs(FWHM_c[1][3]-FWHM_m[1][3])/FWHM_m[1][3];
      con4=abs(FWHM_c[2][3]-FWHM_m[2][3])/FWHM_m[2][3];
	  
	  con7=abs(FWHM_c[1][4]-FWHM_m[1][4])/FWHM_m[1][4];
      con8=abs(FWHM_c[2][4]-FWHM_m[2][4])/FWHM_m[2][4];
	  
	  con9=abs(FWHM_c[1][1]-FWHM_m[1][1])/FWHM_m[1][1]; //1st position
      con10=abs(FWHM_c[2][1]-FWHM_m[2][1])/FWHM_m[2][1]; 
	  
	  con11=abs(FWHM_c[1][5]-FWHM_m[1][5])/FWHM_m[1][5]; //5th position
      con12=abs(FWHM_c[2][5]-FWHM_m[2][5])/FWHM_m[2][5];
	  
	  con5=abs(gradixc-gradixm)/gradixm;
	  con6=abs(gradiyc-gradiym)/gradiym;
	  
	if (kkkkk>looplimit+1) break;
	  ////********************************************
	  //  record the best set of parameters
	  ////********************************************
      float ParameterIndex = (con1 + con2 + con7 + con8 + con9 + con10 + con11 + con12)*weight2 + (con3 + con4)*weight3;
	  
      if (best>ParameterIndex) 
	  {
	   best = ParameterIndex ;
       bestxWidth= xWidth; 
       bestyWidth= yWidth;
       bestcxWidth= cxWidth;
	   bestcyWidth= cyWidth;
	   }
	   
	  ////********************************************
	  //  end of recording the best set of parameters
	  ////********************************************
	  
	  if(kkkkk==1)
	  {
	  gradixcO=gradixc;
	  gradiycO=gradiyc;

	  FWHMxcO = FWHM_c[1][3];
	  FWHMycO = FWHM_c[2][3];
	  
	  FWHMxcO1 = FWHM_c[1][1];
	  FWHMycO1 = FWHM_c[2][1];  
	  }
	  
      if (con9<limit2 && con10<limit2 && con3<limit3 && con4<limit3 && con5<limit4o && con6<limit4o) break;
      if (mmm>4) break;	  

//      con1: abs(FWHM_c[1][2]-FWHM_m[1][2])/FWHM_m[1][2];
//      con2: abs(FWHM_c[2][2]-FWHM_m[2][2])/FWHM_m[2][2];
//      con3: abs(FWHM_c[1][3]-FWHM_m[1][3])/FWHM_m[1][3];
//      con4: abs(FWHM_c[2][3]-FWHM_m[2][3])/FWHM_m[2][3];
//      con7: abs(FWHM_c[1][4]-FWHM_m[1][4])/FWHM_m[1][4];
//      con8: abs(FWHM_c[2][4]-FWHM_m[2][4])/FWHM_m[2][4];
//      con9: abs(FWHM_c[1][1]-FWHM_m[1][1])/FWHM_m[1][1]; //1st position
//      con10: abs(FWHM_c[2][1]-FWHM_m[2][1])/FWHM_m[2][1];
//      con11: abs(FWHM_c[1][5]-FWHM_m[1][5])/FWHM_m[1][5]; //5th position
//      con12: abs(FWHM_c[2][5]-FWHM_m[2][5])/FWHM_m[2][5];
//      con5: abs(gradixc-gradixm)/gradixm;
//      con6: abs(gradiyc-gradiym)/gradiym;
				  
//check FWHM in x

      if (nnx1>5)limit4x= 100000.0;
	  else if (cxWidth<0.0001 && (gradixm-gradixc)<0.0)limit4y= 100000.0;
      else       limit4x= limit4o;		 

	  if (XratioCM3>limitx1 || XratioCM3< 1.0/limitx1)
//	  if (XratioCM3>limitx1 || XratioCM1 > limitx1)
	  {
           nnxL=nnxL+1;
           if(nnxL>5) limitx1=limitx1*2.0;
           else       limitx1=limitx1O;
	    if(XratioCM3 > limitx1) sign=-1;
	    if(XratioCM3 < 1.0/limitx1) sign=1;
	    deltaWidthcx=cxWidth*0.5*sign;
            deltaWidthx=0.0;
	   }
      else if (XratioCM1 > limitx1 || XratioCM1<1.0/limitx1)	
//	  else if (XratioCM3< 1.0/limitx1 || XratioCM1<1.0/limitx1)
	  {
           nnxL=0;
		if(XratioCM1 > limitx1) sign=-1;
		if(XratioCM1 < 1.0/limitx1) sign=1;
		deltaWidthx=xWidth*0.5*sign;	 
                deltaWidthcx=0.0;	  
	  }
	  
	  else{
          nnxL=0;
            if(con5>limit4x )
			{
		         nnx1=nnx1+1;		 
	             nnx2=0;
     			 nnx3=0;
                 double Ratio;				 
	             if(nnx1>2)  
				 {
                   if((gradixcO-gradixm)*(gradixc-gradixm)>0.0) 
					 {				
					 ratiocx=1.25*ratiocx;
					 }
		      	     else
					 {
						 ratiocx=1.0/1.25*ratiocx;
                     } 
								 
		         }
		         else        ratiocx=ratiocxo;
                 
				 
                 for (; ;)
			     {
	                   deltaWidthcx = ratiocx*(gradixm-gradixc)/(gradixm*1.0);
	                   if ((cxWidth + deltaWidthcx)<=0.0) ratiocx=0.5*ratiocx;
		               else break;
	             }
                 deltaWidthx = 0.0;
//                 cout<<"BBBBBBBBBBBBBBBBBBBBBBBBBBB;;;;;"<<endl;
	        }
	        else if(con3>limit3 && con5<limit4x)
			{
	             nnx1=0; 
	             nnx2=nnx2+1;
	             nnx3=0;
				 double Ratio;
	             if(nnx2>2) 
			     {
                   if ((FWHMxcO-FWHM_m[1][3])*(FWHM_c[1][3]-FWHM_m[1][3])>0)
                     {
					  ratiox=1.25*ratiox;
	  	             }
					 else 
                     {
					 ratiox=1.0/1.25*ratiox;
					 } 
	  	         }  
	             else      ratiox=ratioxo;
				 
	             for (; ;)
				 {
	                 deltaWidthx = ratiox*(FWHM_m[1][3]-FWHM_c[1][3])/FWHM_m[1][3];
	                 if ((xWidth + deltaWidthx)<=0.0) ratiox=0.5*ratiox;
	  	             else break;
	             }
				 
            	     deltaWidthcx = 0.0;
	        }
		     else if(con9>limit2 && con3<limit3 && con5<limit4x)
			{
	             nnx1=0; 
	             nnx2=0;
	             nnx3=nnx3+1;
				 double Ratio;
	             if(nnx3>2) 
				 {
	  	              if ((FWHMxcO1-FWHM_m[1][1])*(FWHM_c[1][1]-FWHM_m[1][1])>0)
                     {
						 ratiox=1.25*ratiox;
	  	             }
					 else  
					 {
				     ratiox=1.0/1.25*ratiox;
	  	             }         
					 
				 }  
	             else      ratiox=ratioxo;
				 
	             for (; ;)
				 {
	                 deltaWidthx = ratiox*(FWHM_m[1][1]-FWHM_c[1][1])/FWHM_m[1][1];
	                 if ((xWidth + deltaWidthx)<=0.0) ratiox=0.5*ratiox;
	  	             else break;
	             }
				 
            	     deltaWidthcx = 0.0;
	        }

            else
			{ 
			     deltaWidthx = 0.0;
	             deltaWidthcx = 0.0;
	        }
	  
	  }
	  
//end of checking FWHM in x
	  	  
//check FWHM in y	
	  if (nny1>5)limit4y= 100000.0;
	  else if (cyWidth<0.0001 && (gradiym-gradiyc)<0.0)limit4y= 100000.0;
      else       limit4y= limit4o;
  
	  if (YratioCM3>limity1 || YratioCM3<1.0/limity1)
//	  if (YratioCM3>limity1 || YratioCM1>limity1)
	  { 
          nnyL=nnyL+1;  
          if(nnyL>5) limity1=limity1*2.0;
          else       limity1=limity1O;

          if(YratioCM3>limity1) sign=-1;
		  if(YratioCM3<1.0/limity1) sign=1;
		  deltaWidthcy=cyWidth*0.5*sign;
	      deltaWidthy=0.0;
 	  }
	  
      else if (YratioCM1>limity1 || YratioCM1<1.0/limity1 )  
//	   else if (YratioCM3<1.0/limity1 || YratioCM1<1.0/limity1 )
	  {   
	      nnyL=0;	
	      if(YratioCM1>limity1) sign=-1.0;
		  if(YratioCM1<1.0/limity1) sign=1.0;
	      deltaWidthy = yWidth*0.5*sign;
	      deltaWidthcy= 0.0;
	  }
	  
	  else
	  {
          nnyL=0;       
           if(con6>limit4y){
		         nny1=nny1+1;
	             nny2=0;
                 nny3=0;
				 double Ratio;
 	             if(nny1>2) 
			     { 
 		             if((gradiycO-gradiym)*(gradiyc-gradiym)>0.0) ratiocy=1.25*ratiocy;
		     	     else ratiocy=1/1.25*ratiocy;
                     
		       	 }
		         else ratiocy=ratiocyo; 
                 
		         for (; ;){
	                 deltaWidthcy = ratiocy*(gradiym-gradiyc)/(gradiym*1.0);
    			//	 deltaWidthcy = ratiocy*(gradiym-gradiyc);
	                 if ((cyWidth + deltaWidthcy)<=0.0) ratiocy=0.5*ratiocy;
		             else break;
	             }
					
		         deltaWidthy=0.0;
           }	
	  
	        else if(con4>limit3 && con6<limit4y ){
		        nny1=0;
		        nny2=nny2+1;
		        double Ratio;
		         if(nny2>2) {
		             if((FWHMycO-FWHM_m[2][3])*(FWHM_c[2][3]-FWHM_m[2][3])>0.0)  
					 {	 
					 ratioy=1.25*ratioy; 
					 }
		            else
					{
						ratioy=1.0/1.25*ratioy;
					}	 	
		        } 
		        
		        else       ratioy=ratioyo;
				
				
	            for (; ;)
			    {
	                 deltaWidthy = ratioy*(FWHM_m[2][3]-FWHM_c[2][3])/FWHM_m[2][3];
	                 if ((yWidth + deltaWidthy)<=0.0) ratioy=0.5*ratioy;
		            else break;
	            }
		        deltaWidthcy=0.0;
            }
            else if	(con10>limit2 && con4<limit3 && con6<limit4y )
			{
		        nny1=0;
				nny2=0;
		        nny3=nny3+1;
		        double Ratio;
 		        if(nny3>2)
				{
		      	      if((FWHMycO1-FWHM_m[2][1])*(FWHM_c[2][1]-FWHM_m[2][1])>0.0)  ratioy=1.25*ratioy; 
		      	     else
					 {ratioy=1.0/1.25*ratioy;  
                     }					 
				} 
				else ratioy=ratioyo;
				
				for (; ;)
			    {
	                 deltaWidthy = ratioy*(FWHM_m[2][1]-FWHM_c[2][1])/FWHM_m[2][1];
	                 if ((yWidth + deltaWidthy)<=0.0) ratioy=0.5*ratioy;
		      	     else break;
	            }
		        deltaWidthcy=0.0;
			}				
			else
			{
			    deltaWidthy = 0.0;
				deltaWidthcy =0.0;
			}  
	 } 

// end of checking FWHM in y

//	  cout<<"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB, "<<ratiocy<<", "<<deltaWidthcy<<endl;
 	  gradixcO=gradixc;
	  gradiycO=gradiyc;

	  FWHMxcO = FWHM_c[1][3];
	  FWHMycO = FWHM_c[2][3];
	  
	  FWHMxcO1 = FWHM_c[1][1];
	  FWHMycO1 = FWHM_c[2][1];
	  
	  xWidth = xWidth + deltaWidthx;
	  cxWidth = cxWidth + deltaWidthcx;
	  
      yWidth = yWidth + deltaWidthy; 
	  cyWidth = cyWidth + deltaWidthcy;
	  
	  if (kkkkk>looplimit){
		xWidth = bestxWidth; 
	    yWidth = bestyWidth;
	    cxWidth = bestcxWidth;
	    cyWidth = bestcyWidth;
	    cout<<"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA kkkkk="<<kkkkk<<endl;
	  }

//end of checking FWHM in x Angle check
	 
     if (abs(deltaWidthx)<0.0001 && abs(deltaWidthy)<0.0001 && abs(deltaWidthcx)<0.00001 && abs(deltaWidthcy) < 0.00001)
	 { 
     mmm=mmm+1;
//	 if (xWidth==0.0 ||yWidth==0.0 || cxWidth==0.0 ||cyWidth==0.0) mmm=mmm-1;
	 }
         else mmm=0;
     
  } 
 
//  float DeviX = sqrt((con1*con1+con7*con7+con9*con9+con11*con11+con3*con3)/5.0);

//  float DeviY = sqrt((con2*con2+con8*con8+con10*con10+con12*con12+con4*con4)/5.0);

//  cout<<"DeviX "<<DeviX<<endl;
//  cout<<"DeviY "<<DeviY<<endl;

 
  //End of calculating raw opening angles in x and y
	 
   if (nominalEnergy<100.0){
   printf("%4.1f:%f:%f:%f:%f:%f:%f\n",nominalEnergy,realEnergy,EnergyWidth, xWidth, yWidth, cxWidth, cyWidth );}
   else {
   printf("%5.1f:%f:%f:%f:%f:%f:%f\n",nominalEnergy,realEnergy,EnergyWidth, xWidth, yWidth, cxWidth, cyWidth );} 

   return 0;

}
